"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
exports.config = exports.configSchema = void 0;

var _configSchema = require("@kbn/config-schema");

var _plugin = require("./plugin");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
const configSchema = _configSchema.schema.object({
  enabled: _configSchema.schema.boolean({
    defaultValue: true
  })
});

exports.configSchema = configSchema;
const config = {
  exposeToBrowser: {
    // following configs are visible to browser side plugin
    enabled: true
  },
  schema: configSchema
}; // entry point

exports.config = config;

function plugin(initializerContext) {
  return new _plugin.AlertingPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbImNvbmZpZ1NjaGVtYSIsInNjaGVtYSIsIm9iamVjdCIsImVuYWJsZWQiLCJib29sZWFuIiwiZGVmYXVsdFZhbHVlIiwiY29uZmlnIiwiZXhwb3NlVG9Ccm93c2VyIiwicGx1Z2luIiwiaW5pdGlhbGl6ZXJDb250ZXh0IiwiQWxlcnRpbmdQbHVnaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBZUE7O0FBQ0E7O0FBaEJBOzs7Ozs7Ozs7Ozs7OztBQWtCTyxNQUFNQSxZQUFZLEdBQUdDLHFCQUFPQyxNQUFQLENBQWM7QUFDeENDLEVBQUFBLE9BQU8sRUFBRUYscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxJQUFBQSxZQUFZLEVBQUU7QUFBaEIsR0FBZjtBQUQrQixDQUFkLENBQXJCOzs7QUFJQSxNQUFNQyxNQUFNLEdBQUc7QUFDcEJDLEVBQUFBLGVBQWUsRUFBRTtBQUNmO0FBQ0FKLElBQUFBLE9BQU8sRUFBRTtBQUZNLEdBREc7QUFLcEJGLEVBQUFBLE1BQU0sRUFBRUQ7QUFMWSxDQUFmLEMsQ0FRUDs7OztBQUNPLFNBQVNRLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUFvQztBQUN6QyxTQUFPLElBQUlDLHNCQUFKLENBQW1CRCxrQkFBbkIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IDIwMjAgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0BrYm4vY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQgeyBBbGVydGluZ1BsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuZXhwb3J0IGNvbnN0IGNvbmZpZ1NjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICBlbmFibGVkOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogdHJ1ZSB9KSxcbn0pO1xuXG5leHBvcnQgY29uc3QgY29uZmlnID0ge1xuICBleHBvc2VUb0Jyb3dzZXI6IHtcbiAgICAvLyBmb2xsb3dpbmcgY29uZmlncyBhcmUgdmlzaWJsZSB0byBicm93c2VyIHNpZGUgcGx1Z2luXG4gICAgZW5hYmxlZDogdHJ1ZSxcbiAgfSxcbiAgc2NoZW1hOiBjb25maWdTY2hlbWEsXG59O1xuXG4vLyBlbnRyeSBwb2ludFxuZXhwb3J0IGZ1bmN0aW9uIHBsdWdpbihpbml0aWFsaXplckNvbnRleHQpIHtcbiAgcmV0dXJuIG5ldyBBbGVydGluZ1BsdWdpbihpbml0aWFsaXplckNvbnRleHQpO1xufVxuIl19