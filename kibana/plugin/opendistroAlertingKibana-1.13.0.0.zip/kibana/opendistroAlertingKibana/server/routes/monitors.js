"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _configSchema = require("@kbn/config-schema");

/*
 *   Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function _default(services, router) {
  const {
    monitorService
  } = services;
  router.get({
    path: '/api/alerting/monitors',
    validate: {
      query: _configSchema.schema.object({
        from: _configSchema.schema.number(),
        size: _configSchema.schema.number(),
        search: _configSchema.schema.string(),
        sortField: _configSchema.schema.string(),
        sortDirection: _configSchema.schema.string(),
        state: _configSchema.schema.string()
      })
    }
  }, monitorService.getMonitors);
  router.post({
    path: '/api/alerting/monitors/_search',
    validate: {
      body: _configSchema.schema.any()
    }
  }, monitorService.searchMonitors);
  router.post({
    path: '/api/alerting/monitors',
    validate: {
      body: _configSchema.schema.any()
    }
  }, monitorService.createMonitor);
  router.post({
    path: '/api/alerting/monitors/_execute',
    validate: {
      query: _configSchema.schema.object({
        dryrun: _configSchema.schema.maybe(_configSchema.schema.string())
      }),
      body: _configSchema.schema.any()
    }
  }, monitorService.executeMonitor);
  router.get({
    path: '/api/alerting/monitors/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, monitorService.getMonitor);
  router.put({
    path: '/api/alerting/monitors/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      query: _configSchema.schema.object({
        ifSeqNo: _configSchema.schema.number(),
        ifPrimaryTerm: _configSchema.schema.number()
      }),
      body: _configSchema.schema.any()
    }
  }, monitorService.updateMonitor);
  router.delete({
    path: '/api/alerting/monitors/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      query: _configSchema.schema.object({
        version: _configSchema.schema.number()
      })
    }
  }, monitorService.deleteMonitor);
  router.post({
    path: '/api/alerting/monitors/{id}/_acknowledge/alerts',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.any()
    }
  }, monitorService.acknowledgeAlerts);
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vbml0b3JzLmpzIl0sIm5hbWVzIjpbInNlcnZpY2VzIiwicm91dGVyIiwibW9uaXRvclNlcnZpY2UiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsImZyb20iLCJudW1iZXIiLCJzaXplIiwic2VhcmNoIiwic3RyaW5nIiwic29ydEZpZWxkIiwic29ydERpcmVjdGlvbiIsInN0YXRlIiwiZ2V0TW9uaXRvcnMiLCJwb3N0IiwiYm9keSIsImFueSIsInNlYXJjaE1vbml0b3JzIiwiY3JlYXRlTW9uaXRvciIsImRyeXJ1biIsIm1heWJlIiwiZXhlY3V0ZU1vbml0b3IiLCJwYXJhbXMiLCJpZCIsImdldE1vbml0b3IiLCJwdXQiLCJpZlNlcU5vIiwiaWZQcmltYXJ5VGVybSIsInVwZGF0ZU1vbml0b3IiLCJkZWxldGUiLCJ2ZXJzaW9uIiwiZGVsZXRlTW9uaXRvciIsImFja25vd2xlZGdlQWxlcnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBZkE7Ozs7Ozs7Ozs7Ozs7O0FBaUJlLGtCQUFVQSxRQUFWLEVBQW9CQyxNQUFwQixFQUE0QjtBQUN6QyxRQUFNO0FBQUVDLElBQUFBO0FBQUYsTUFBcUJGLFFBQTNCO0FBRUFDLEVBQUFBLE1BQU0sQ0FBQ0UsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSx3QkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUkMsTUFBQUEsS0FBSyxFQUFFQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ25CQyxRQUFBQSxJQUFJLEVBQUVGLHFCQUFPRyxNQUFQLEVBRGE7QUFFbkJDLFFBQUFBLElBQUksRUFBRUoscUJBQU9HLE1BQVAsRUFGYTtBQUduQkUsUUFBQUEsTUFBTSxFQUFFTCxxQkFBT00sTUFBUCxFQUhXO0FBSW5CQyxRQUFBQSxTQUFTLEVBQUVQLHFCQUFPTSxNQUFQLEVBSlE7QUFLbkJFLFFBQUFBLGFBQWEsRUFBRVIscUJBQU9NLE1BQVAsRUFMSTtBQU1uQkcsUUFBQUEsS0FBSyxFQUFFVCxxQkFBT00sTUFBUDtBQU5ZLE9BQWQ7QUFEQztBQUZaLEdBREYsRUFjRVgsY0FBYyxDQUFDZSxXQWRqQjtBQWlCQWhCLEVBQUFBLE1BQU0sQ0FBQ2lCLElBQVAsQ0FDRTtBQUNFZCxJQUFBQSxJQUFJLEVBQUUsZ0NBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1JjLE1BQUFBLElBQUksRUFBRVoscUJBQU9hLEdBQVA7QUFERTtBQUZaLEdBREYsRUFPRWxCLGNBQWMsQ0FBQ21CLGNBUGpCO0FBVUFwQixFQUFBQSxNQUFNLENBQUNpQixJQUFQLENBQ0U7QUFDRWQsSUFBQUEsSUFBSSxFQUFFLHdCQURSO0FBRUVDLElBQUFBLFFBQVEsRUFBRTtBQUNSYyxNQUFBQSxJQUFJLEVBQUVaLHFCQUFPYSxHQUFQO0FBREU7QUFGWixHQURGLEVBT0VsQixjQUFjLENBQUNvQixhQVBqQjtBQVVBckIsRUFBQUEsTUFBTSxDQUFDaUIsSUFBUCxDQUNFO0FBQ0VkLElBQUFBLElBQUksRUFBRSxpQ0FEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUkMsTUFBQUEsS0FBSyxFQUFFQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ25CZSxRQUFBQSxNQUFNLEVBQUVoQixxQkFBT2lCLEtBQVAsQ0FBYWpCLHFCQUFPTSxNQUFQLEVBQWI7QUFEVyxPQUFkLENBREM7QUFJUk0sTUFBQUEsSUFBSSxFQUFFWixxQkFBT2EsR0FBUDtBQUpFO0FBRlosR0FERixFQVVFbEIsY0FBYyxDQUFDdUIsY0FWakI7QUFhQXhCLEVBQUFBLE1BQU0sQ0FBQ0UsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSw2QkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUnFCLE1BQUFBLE1BQU0sRUFBRW5CLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJtQixRQUFBQSxFQUFFLEVBQUVwQixxQkFBT00sTUFBUDtBQURnQixPQUFkO0FBREE7QUFGWixHQURGLEVBU0VYLGNBQWMsQ0FBQzBCLFVBVGpCO0FBWUEzQixFQUFBQSxNQUFNLENBQUM0QixHQUFQLENBQ0U7QUFDRXpCLElBQUFBLElBQUksRUFBRSw2QkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUnFCLE1BQUFBLE1BQU0sRUFBRW5CLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJtQixRQUFBQSxFQUFFLEVBQUVwQixxQkFBT00sTUFBUDtBQURnQixPQUFkLENBREE7QUFJUlAsTUFBQUEsS0FBSyxFQUFFQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ25Cc0IsUUFBQUEsT0FBTyxFQUFFdkIscUJBQU9HLE1BQVAsRUFEVTtBQUVuQnFCLFFBQUFBLGFBQWEsRUFBRXhCLHFCQUFPRyxNQUFQO0FBRkksT0FBZCxDQUpDO0FBUVJTLE1BQUFBLElBQUksRUFBRVoscUJBQU9hLEdBQVA7QUFSRTtBQUZaLEdBREYsRUFjRWxCLGNBQWMsQ0FBQzhCLGFBZGpCO0FBaUJBL0IsRUFBQUEsTUFBTSxDQUFDZ0MsTUFBUCxDQUNFO0FBQ0U3QixJQUFBQSxJQUFJLEVBQUUsNkJBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1JxQixNQUFBQSxNQUFNLEVBQUVuQixxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCbUIsUUFBQUEsRUFBRSxFQUFFcEIscUJBQU9NLE1BQVA7QUFEZ0IsT0FBZCxDQURBO0FBSVJQLE1BQUFBLEtBQUssRUFBRUMscUJBQU9DLE1BQVAsQ0FBYztBQUNuQjBCLFFBQUFBLE9BQU8sRUFBRTNCLHFCQUFPRyxNQUFQO0FBRFUsT0FBZDtBQUpDO0FBRlosR0FERixFQVlFUixjQUFjLENBQUNpQyxhQVpqQjtBQWVBbEMsRUFBQUEsTUFBTSxDQUFDaUIsSUFBUCxDQUNFO0FBQ0VkLElBQUFBLElBQUksRUFBRSxpREFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUnFCLE1BQUFBLE1BQU0sRUFBRW5CLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJtQixRQUFBQSxFQUFFLEVBQUVwQixxQkFBT00sTUFBUDtBQURnQixPQUFkLENBREE7QUFJUk0sTUFBQUEsSUFBSSxFQUFFWixxQkFBT2EsR0FBUDtBQUpFO0FBRlosR0FERixFQVVFbEIsY0FBYyxDQUFDa0MsaUJBVmpCO0FBWUQiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogICBDb3B5cmlnaHQgMjAxOSBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqICAgTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS5cbiAqICAgWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqICAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqICAgb3IgaW4gdGhlIFwibGljZW5zZVwiIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkXG4gKiAgIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xuICogICBwZXJtaXNzaW9ucyBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQGtibi9jb25maWctc2NoZW1hJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHNlcnZpY2VzLCByb3V0ZXIpIHtcbiAgY29uc3QgeyBtb25pdG9yU2VydmljZSB9ID0gc2VydmljZXM7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9hbGVydGluZy9tb25pdG9ycycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgZnJvbTogc2NoZW1hLm51bWJlcigpLFxuICAgICAgICAgIHNpemU6IHNjaGVtYS5udW1iZXIoKSxcbiAgICAgICAgICBzZWFyY2g6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBzb3J0RmllbGQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBzb3J0RGlyZWN0aW9uOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgc3RhdGU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgbW9uaXRvclNlcnZpY2UuZ2V0TW9uaXRvcnNcbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9hbGVydGluZy9tb25pdG9ycy9fc2VhcmNoJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBtb25pdG9yU2VydmljZS5zZWFyY2hNb25pdG9yc1xuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2FsZXJ0aW5nL21vbml0b3JzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBtb25pdG9yU2VydmljZS5jcmVhdGVNb25pdG9yXG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvYWxlcnRpbmcvbW9uaXRvcnMvX2V4ZWN1dGUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGRyeXJ1bjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXG4gICAgICB9LFxuICAgIH0sXG4gICAgbW9uaXRvclNlcnZpY2UuZXhlY3V0ZU1vbml0b3JcbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2FsZXJ0aW5nL21vbml0b3JzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBtb25pdG9yU2VydmljZS5nZXRNb25pdG9yXG4gICk7XG5cbiAgcm91dGVyLnB1dChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9hbGVydGluZy9tb25pdG9ycy97aWR9JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZlNlcU5vOiBzY2hlbWEubnVtYmVyKCksXG4gICAgICAgICAgaWZQcmltYXJ5VGVybTogc2NoZW1hLm51bWJlcigpLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgfSxcbiAgICB9LFxuICAgIG1vbml0b3JTZXJ2aWNlLnVwZGF0ZU1vbml0b3JcbiAgKTtcblxuICByb3V0ZXIuZGVsZXRlKFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2FsZXJ0aW5nL21vbml0b3JzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHZlcnNpb246IHNjaGVtYS5udW1iZXIoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgbW9uaXRvclNlcnZpY2UuZGVsZXRlTW9uaXRvclxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2FsZXJ0aW5nL21vbml0b3JzL3tpZH0vX2Fja25vd2xlZGdlL2FsZXJ0cycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXG4gICAgICB9LFxuICAgIH0sXG4gICAgbW9uaXRvclNlcnZpY2UuYWNrbm93bGVkZ2VBbGVydHNcbiAgKTtcbn1cbiJdfQ==