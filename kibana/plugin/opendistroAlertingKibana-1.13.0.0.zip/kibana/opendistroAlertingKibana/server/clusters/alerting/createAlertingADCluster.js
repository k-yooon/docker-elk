"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = createAlertingADCluster;

var _adPlugin = _interopRequireDefault(require("./adPlugin"));

var _constants = require("../../services/utils/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function createAlertingADCluster(core, globalConfig) {
  const {
    customHeaders,
    ...rest
  } = globalConfig.elasticsearch;
  return core.elasticsearch.legacy.createClient(_constants.CLUSTER.AD_ALERTING, {
    plugins: [_adPlugin.default],
    // Currently we are overriding any headers with our own since we explicitly required User-Agent to be Kibana
    // for integration with our backend plugin.
    // TODO: Change our required header to x-<Header> to avoid overriding
    customHeaders: { ...customHeaders,
      ..._constants.DEFAULT_HEADERS
    },
    ...rest
  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZUFsZXJ0aW5nQURDbHVzdGVyLmpzIl0sIm5hbWVzIjpbImNyZWF0ZUFsZXJ0aW5nQURDbHVzdGVyIiwiY29yZSIsImdsb2JhbENvbmZpZyIsImN1c3RvbUhlYWRlcnMiLCJyZXN0IiwiZWxhc3RpY3NlYXJjaCIsImxlZ2FjeSIsImNyZWF0ZUNsaWVudCIsIkNMVVNURVIiLCJBRF9BTEVSVElORyIsInBsdWdpbnMiLCJhbGVydGluZ0FEUGx1Z2luIiwiREVGQVVMVF9IRUFERVJTIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBQ0E7Ozs7QUFoQkE7Ozs7Ozs7Ozs7Ozs7O0FBa0JlLFNBQVNBLHVCQUFULENBQWlDQyxJQUFqQyxFQUF1Q0MsWUFBdkMsRUFBcUQ7QUFDbEUsUUFBTTtBQUFFQyxJQUFBQSxhQUFGO0FBQWlCLE9BQUdDO0FBQXBCLE1BQTZCRixZQUFZLENBQUNHLGFBQWhEO0FBQ0EsU0FBT0osSUFBSSxDQUFDSSxhQUFMLENBQW1CQyxNQUFuQixDQUEwQkMsWUFBMUIsQ0FBdUNDLG1CQUFRQyxXQUEvQyxFQUE0RDtBQUNqRUMsSUFBQUEsT0FBTyxFQUFFLENBQUNDLGlCQUFELENBRHdEO0FBRWpFO0FBQ0E7QUFDQTtBQUNBUixJQUFBQSxhQUFhLEVBQUUsRUFBRSxHQUFHQSxhQUFMO0FBQW9CLFNBQUdTO0FBQXZCLEtBTGtEO0FBTWpFLE9BQUdSO0FBTjhELEdBQTVELENBQVA7QUFRRCIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiAgIENvcHlyaWdodCAyMDIwIEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogICBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqICAgb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgYWxlcnRpbmdBRFBsdWdpbiBmcm9tICcuL2FkUGx1Z2luJztcbmltcG9ydCB7IENMVVNURVIsIERFRkFVTFRfSEVBREVSUyB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3V0aWxzL2NvbnN0YW50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZUFsZXJ0aW5nQURDbHVzdGVyKGNvcmUsIGdsb2JhbENvbmZpZykge1xuICBjb25zdCB7IGN1c3RvbUhlYWRlcnMsIC4uLnJlc3QgfSA9IGdsb2JhbENvbmZpZy5lbGFzdGljc2VhcmNoO1xuICByZXR1cm4gY29yZS5lbGFzdGljc2VhcmNoLmxlZ2FjeS5jcmVhdGVDbGllbnQoQ0xVU1RFUi5BRF9BTEVSVElORywge1xuICAgIHBsdWdpbnM6IFthbGVydGluZ0FEUGx1Z2luXSxcbiAgICAvLyBDdXJyZW50bHkgd2UgYXJlIG92ZXJyaWRpbmcgYW55IGhlYWRlcnMgd2l0aCBvdXIgb3duIHNpbmNlIHdlIGV4cGxpY2l0bHkgcmVxdWlyZWQgVXNlci1BZ2VudCB0byBiZSBLaWJhbmFcbiAgICAvLyBmb3IgaW50ZWdyYXRpb24gd2l0aCBvdXIgYmFja2VuZCBwbHVnaW4uXG4gICAgLy8gVE9ETzogQ2hhbmdlIG91ciByZXF1aXJlZCBoZWFkZXIgdG8geC08SGVhZGVyPiB0byBhdm9pZCBvdmVycmlkaW5nXG4gICAgY3VzdG9tSGVhZGVyczogeyAuLi5jdXN0b21IZWFkZXJzLCAuLi5ERUZBVUxUX0hFQURFUlMgfSxcbiAgICAuLi5yZXN0LFxuICB9KTtcbn1cbiJdfQ==