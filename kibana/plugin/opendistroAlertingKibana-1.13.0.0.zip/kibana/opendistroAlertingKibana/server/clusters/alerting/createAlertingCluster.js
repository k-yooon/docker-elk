"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = createAlertingCluster;

var _alertingPlugin = _interopRequireDefault(require("./alertingPlugin"));

var _constants = require("../../services/utils/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 *   Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function createAlertingCluster(core, globalConfig) {
  const {
    customHeaders,
    ...rest
  } = globalConfig.elasticsearch;
  return core.elasticsearch.legacy.createClient(_constants.CLUSTER.ALERTING, {
    plugins: [_alertingPlugin.default],
    // Currently we are overriding any headers with our own since we explicitly required User-Agent to be Kibana
    // for integration with our backend plugin.
    // TODO: Change our required header to x-<Header> to avoid overriding
    customHeaders: { ...customHeaders,
      ..._constants.DEFAULT_HEADERS
    },
    ...rest
  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZUFsZXJ0aW5nQ2x1c3Rlci5qcyJdLCJuYW1lcyI6WyJjcmVhdGVBbGVydGluZ0NsdXN0ZXIiLCJjb3JlIiwiZ2xvYmFsQ29uZmlnIiwiY3VzdG9tSGVhZGVycyIsInJlc3QiLCJlbGFzdGljc2VhcmNoIiwibGVnYWN5IiwiY3JlYXRlQ2xpZW50IiwiQ0xVU1RFUiIsIkFMRVJUSU5HIiwicGx1Z2lucyIsImFsZXJ0aW5nUGx1Z2luIiwiREVGQVVMVF9IRUFERVJTIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBQ0E7Ozs7QUFoQkE7Ozs7Ozs7Ozs7Ozs7O0FBa0JlLFNBQVNBLHFCQUFULENBQStCQyxJQUEvQixFQUFxQ0MsWUFBckMsRUFBbUQ7QUFDaEUsUUFBTTtBQUFFQyxJQUFBQSxhQUFGO0FBQWlCLE9BQUdDO0FBQXBCLE1BQTZCRixZQUFZLENBQUNHLGFBQWhEO0FBQ0EsU0FBT0osSUFBSSxDQUFDSSxhQUFMLENBQW1CQyxNQUFuQixDQUEwQkMsWUFBMUIsQ0FBdUNDLG1CQUFRQyxRQUEvQyxFQUF5RDtBQUM5REMsSUFBQUEsT0FBTyxFQUFFLENBQUNDLHVCQUFELENBRHFEO0FBRTlEO0FBQ0E7QUFDQTtBQUNBUixJQUFBQSxhQUFhLEVBQUUsRUFBRSxHQUFHQSxhQUFMO0FBQW9CLFNBQUdTO0FBQXZCLEtBTCtDO0FBTTlELE9BQUdSO0FBTjJELEdBQXpELENBQVA7QUFRRCIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiAgIENvcHlyaWdodCAyMDE5IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogICBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqICAgb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgYWxlcnRpbmdQbHVnaW4gZnJvbSAnLi9hbGVydGluZ1BsdWdpbic7XG5pbXBvcnQgeyBDTFVTVEVSLCBERUZBVUxUX0hFQURFUlMgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy91dGlscy9jb25zdGFudHMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjcmVhdGVBbGVydGluZ0NsdXN0ZXIoY29yZSwgZ2xvYmFsQ29uZmlnKSB7XG4gIGNvbnN0IHsgY3VzdG9tSGVhZGVycywgLi4ucmVzdCB9ID0gZ2xvYmFsQ29uZmlnLmVsYXN0aWNzZWFyY2g7XG4gIHJldHVybiBjb3JlLmVsYXN0aWNzZWFyY2gubGVnYWN5LmNyZWF0ZUNsaWVudChDTFVTVEVSLkFMRVJUSU5HLCB7XG4gICAgcGx1Z2luczogW2FsZXJ0aW5nUGx1Z2luXSxcbiAgICAvLyBDdXJyZW50bHkgd2UgYXJlIG92ZXJyaWRpbmcgYW55IGhlYWRlcnMgd2l0aCBvdXIgb3duIHNpbmNlIHdlIGV4cGxpY2l0bHkgcmVxdWlyZWQgVXNlci1BZ2VudCB0byBiZSBLaWJhbmFcbiAgICAvLyBmb3IgaW50ZWdyYXRpb24gd2l0aCBvdXIgYmFja2VuZCBwbHVnaW4uXG4gICAgLy8gVE9ETzogQ2hhbmdlIG91ciByZXF1aXJlZCBoZWFkZXIgdG8geC08SGVhZGVyPiB0byBhdm9pZCBvdmVycmlkaW5nXG4gICAgY3VzdG9tSGVhZGVyczogeyAuLi5jdXN0b21IZWFkZXJzLCAuLi5ERUZBVUxUX0hFQURFUlMgfSxcbiAgICAuLi5yZXN0LFxuICB9KTtcbn1cbiJdfQ==