"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../../utils/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class MonitorService {
  constructor(esDriver) {
    _defineProperty(this, "createMonitor", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteMonitor', params);
        return res.ok({
          body: {
            ok: response.result === 'deleted'
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getMonitor', params);

        const monitor = _lodash.default.get(getResponse, 'monitor', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        if (monitor) {
          const {
            callAsCurrentUser
          } = this.esDriver.asScoped(req);
          const searchResponse = await callAsCurrentUser('alerting.getMonitors', {
            index: _constants.INDEX.ALL_ALERTS,
            body: {
              size: 0,
              query: {
                bool: {
                  must: {
                    term: {
                      monitor_id: id
                    }
                  }
                }
              },
              aggs: {
                active_count: {
                  terms: {
                    field: 'state'
                  }
                },
                '24_hour_count': {
                  date_range: {
                    field: 'start_time',
                    ranges: [{
                      from: 'now-24h/h'
                    }]
                  }
                }
              }
            }
          });

          const dayCount = _lodash.default.get(searchResponse, 'aggregations.24_hour_count.buckets.0.doc_count', 0);

          const activeBuckets = _lodash.default.get(searchResponse, 'aggregations.active_count.buckets', []);

          const activeCount = activeBuckets.reduce((acc, curr) => curr.key === 'ACTIVE' ? curr.doc_count : acc, 0);
          return res.ok({
            body: {
              ok: true,
              resp: monitor,
              activeCount,
              dayCount,
              version,
              ifSeqNo,
              ifPrimaryTerm
            }
          });
        } else {
          return res.ok({
            body: {
              ok: false
            }
          });
        }
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "updateMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const {
          ifSeqNo,
          ifPrimaryTerm
        } = req.query;
        const params = {
          monitorId: id,
          ifSeqNo,
          ifPrimaryTerm,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const updateResponse = await callAsCurrentUser('alerting.updateMonitor', params);
        const {
          _version,
          _id
        } = updateResponse;
        return res.ok({
          body: {
            ok: true,
            version: _version,
            id: _id
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - updateMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitors", async (context, req, res) => {
      try {
        const {
          from,
          size,
          search,
          sortDirection,
          sortField,
          state
        } = req.query;
        let must = {
          match_all: {}
        };

        if (search.trim()) {
          // This is an expensive wildcard query to match monitor names such as: "This is a long monitor name"
          // search query => "long monit"
          // This is acceptable because we will never allow more than 1,000 monitors
          must = {
            query_string: {
              default_field: 'monitor.name',
              default_operator: 'AND',
              query: `*${search.trim().split(' ').join('* *')}*`
            }
          };
        }

        const filter = [{
          term: {
            'monitor.type': 'monitor'
          }
        }];

        if (state !== 'all') {
          const enabled = state === 'enabled';
          filter.push({
            term: {
              'monitor.enabled': enabled
            }
          });
        }

        const monitorSorts = {
          name: 'monitor.name.keyword'
        };
        const monitorSortPageData = {
          size: 1000
        };

        if (monitorSorts[sortField]) {
          monitorSortPageData.sort = [{
            [monitorSorts[sortField]]: sortDirection
          }];
          monitorSortPageData.size = _lodash.default.defaultTo(size, 1000);
          monitorSortPageData.from = _lodash.default.defaultTo(from, 0);
        }

        const params = {
          body: {
            seq_no_primary_term: true,
            version: true,
            ...monitorSortPageData,
            query: {
              bool: {
                filter,
                must
              }
            }
          }
        };
        const {
          callAsCurrentUser: alertingCallAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await alertingCallAsCurrentUser('alerting.getMonitors', params);

        const totalMonitors = _lodash.default.get(getResponse, 'hits.total.value', 0);

        const monitorKeyValueTuples = _lodash.default.get(getResponse, 'hits.hits', []).map(result => {
          const {
            _id: id,
            _version: version,
            _seq_no: ifSeqNo,
            _primary_term: ifPrimaryTerm,
            _source: monitor
          } = result;
          const {
            name,
            enabled
          } = monitor;
          return [id, {
            id,
            version,
            ifSeqNo,
            ifPrimaryTerm,
            name,
            enabled,
            monitor
          }];
        }, {});

        const monitorMap = new Map(monitorKeyValueTuples);
        const monitorIds = [...monitorMap.keys()];
        const aggsOrderData = {};
        const aggsSorts = {
          active: 'active',
          acknowledged: 'acknowledged',
          errors: 'errors',
          ignored: 'ignored',
          lastNotificationTime: 'last_notification_time'
        };

        if (aggsSorts[sortField]) {
          aggsOrderData.order = {
            [aggsSorts[sortField]]: sortDirection
          };
        }

        const aggsParams = {
          index: _constants.INDEX.ALL_ALERTS,
          body: {
            size: 0,
            query: {
              terms: {
                monitor_id: monitorIds
              }
            },
            aggregations: {
              uniq_monitor_ids: {
                terms: {
                  field: 'monitor_id',
                  ...aggsOrderData,
                  size: from + size
                },
                aggregations: {
                  active: {
                    filter: {
                      term: {
                        state: 'ACTIVE'
                      }
                    }
                  },
                  acknowledged: {
                    filter: {
                      term: {
                        state: 'ACKNOWLEDGED'
                      }
                    }
                  },
                  errors: {
                    filter: {
                      term: {
                        state: 'ERROR'
                      }
                    }
                  },
                  ignored: {
                    filter: {
                      bool: {
                        filter: {
                          term: {
                            state: 'COMPLETED'
                          }
                        },
                        must_not: {
                          exists: {
                            field: 'acknowledged_time'
                          }
                        }
                      }
                    }
                  },
                  last_notification_time: {
                    max: {
                      field: 'last_notification_time'
                    }
                  },
                  latest_alert: {
                    top_hits: {
                      size: 1,
                      sort: [{
                        start_time: {
                          order: 'desc'
                        }
                      }],
                      _source: {
                        includes: ['last_notification_time', 'trigger_name']
                      }
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const esAggsResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

        const buckets = _lodash.default.get(esAggsResponse, 'aggregations.uniq_monitor_ids.buckets', []).map(bucket => {
          const {
            key: id,
            last_notification_time: {
              value: lastNotificationTime
            },
            ignored: {
              doc_count: ignored
            },
            acknowledged: {
              doc_count: acknowledged
            },
            active: {
              doc_count: active
            },
            errors: {
              doc_count: errors
            },
            latest_alert: {
              hits: {
                hits: [{
                  _source: {
                    trigger_name: latestAlert
                  }
                }]
              }
            }
          } = bucket;
          const monitor = monitorMap.get(id);
          monitorMap.delete(id);
          return { ...monitor,
            id,
            lastNotificationTime,
            ignored,
            latestAlert,
            acknowledged,
            active,
            errors,
            currentTime: Date.now()
          };
        });

        const unusedMonitors = [...monitorMap.values()].map(monitor => ({ ...monitor,
          lastNotificationTime: null,
          ignored: 0,
          active: 0,
          acknowledged: 0,
          errors: 0,
          latestAlert: '--',
          currentTime: Date.now()
        }));

        let results = _lodash.default.orderBy(buckets.concat(unusedMonitors), [sortField], [sortDirection]); // If we sorted on monitor name then we already applied from/size to the first query to limit what we're aggregating over
        // Therefore we do not need to apply from/size to this result set
        // If we sorted on aggregations, then this is our in memory pagination


        if (!monitorSorts[sortField]) {
          results = results.slice(from, from + size);
        }

        return res.ok({
          body: {
            ok: true,
            monitors: results,
            totalMonitors
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitors', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "executeMonitor", async (context, req, res) => {
      try {
        const {
          dryrun = 'true'
        } = req.query;
        const params = {
          body: req.body,
          dryrun
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const executeResponse = await callAsCurrentUser('alerting.executeMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: executeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - executeMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "searchMonitors", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('alerting.getMonitors', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - searchMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = MonitorService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vbml0b3JTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIk1vbml0b3JTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJwYXJhbXMiLCJib2R5IiwiY2FsbEFzQ3VycmVudFVzZXIiLCJhc1Njb3BlZCIsImNyZWF0ZVJlc3BvbnNlIiwib2siLCJyZXNwIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWVzc2FnZSIsImlkIiwibW9uaXRvcklkIiwicmVzcG9uc2UiLCJyZXN1bHQiLCJnZXRSZXNwb25zZSIsIm1vbml0b3IiLCJfIiwiZ2V0IiwidmVyc2lvbiIsImlmU2VxTm8iLCJpZlByaW1hcnlUZXJtIiwic2VhcmNoUmVzcG9uc2UiLCJpbmRleCIsIklOREVYIiwiQUxMX0FMRVJUUyIsInNpemUiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwidGVybSIsIm1vbml0b3JfaWQiLCJhZ2dzIiwiYWN0aXZlX2NvdW50IiwidGVybXMiLCJmaWVsZCIsImRhdGVfcmFuZ2UiLCJyYW5nZXMiLCJmcm9tIiwiZGF5Q291bnQiLCJhY3RpdmVCdWNrZXRzIiwiYWN0aXZlQ291bnQiLCJyZWR1Y2UiLCJhY2MiLCJjdXJyIiwia2V5IiwiZG9jX2NvdW50IiwidXBkYXRlUmVzcG9uc2UiLCJfdmVyc2lvbiIsIl9pZCIsInNlYXJjaCIsInNvcnREaXJlY3Rpb24iLCJzb3J0RmllbGQiLCJzdGF0ZSIsIm1hdGNoX2FsbCIsInRyaW0iLCJxdWVyeV9zdHJpbmciLCJkZWZhdWx0X2ZpZWxkIiwiZGVmYXVsdF9vcGVyYXRvciIsInNwbGl0Iiwiam9pbiIsImZpbHRlciIsImVuYWJsZWQiLCJwdXNoIiwibW9uaXRvclNvcnRzIiwibmFtZSIsIm1vbml0b3JTb3J0UGFnZURhdGEiLCJzb3J0IiwiZGVmYXVsdFRvIiwic2VxX25vX3ByaW1hcnlfdGVybSIsImFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIiLCJ0b3RhbE1vbml0b3JzIiwibW9uaXRvcktleVZhbHVlVHVwbGVzIiwibWFwIiwiX3NlcV9ubyIsIl9wcmltYXJ5X3Rlcm0iLCJfc291cmNlIiwibW9uaXRvck1hcCIsIk1hcCIsIm1vbml0b3JJZHMiLCJrZXlzIiwiYWdnc09yZGVyRGF0YSIsImFnZ3NTb3J0cyIsImFjdGl2ZSIsImFja25vd2xlZGdlZCIsImVycm9ycyIsImlnbm9yZWQiLCJsYXN0Tm90aWZpY2F0aW9uVGltZSIsIm9yZGVyIiwiYWdnc1BhcmFtcyIsImFnZ3JlZ2F0aW9ucyIsInVuaXFfbW9uaXRvcl9pZHMiLCJtdXN0X25vdCIsImV4aXN0cyIsImxhc3Rfbm90aWZpY2F0aW9uX3RpbWUiLCJtYXgiLCJsYXRlc3RfYWxlcnQiLCJ0b3BfaGl0cyIsInN0YXJ0X3RpbWUiLCJpbmNsdWRlcyIsImVzQWdnc1Jlc3BvbnNlIiwiYnVja2V0cyIsImJ1Y2tldCIsInZhbHVlIiwiaGl0cyIsInRyaWdnZXJfbmFtZSIsImxhdGVzdEFsZXJ0IiwiZGVsZXRlIiwiY3VycmVudFRpbWUiLCJEYXRlIiwibm93IiwidW51c2VkTW9uaXRvcnMiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwib3JkZXJCeSIsImNvbmNhdCIsInNsaWNlIiwibW9uaXRvcnMiLCJhY2tub3dsZWRnZVJlc3BvbnNlIiwiZmFpbGVkIiwibGVuZ3RoIiwiZHJ5cnVuIiwiZXhlY3V0ZVJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBRUE7Ozs7OztBQUVlLE1BQU1BLGNBQU4sQ0FBcUI7QUFDbENDLEVBQUFBLFdBQVcsQ0FBQ0MsUUFBRCxFQUFXO0FBQUEsMkNBSU4sT0FBT0MsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNQyxNQUFNLEdBQUc7QUFBRUMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBQVosU0FBZjtBQUNBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNTSxjQUFjLEdBQUcsTUFBTUYsaUJBQWlCLENBQUMsd0JBQUQsRUFBMkJGLE1BQTNCLENBQTlDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUY7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BVkQsQ0FVRSxPQUFPRyxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXhCcUI7O0FBQUEsMkNBMEJOLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUMzQyxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTWUsUUFBUSxHQUFHLE1BQU1YLGlCQUFpQixDQUFDLHdCQUFELEVBQTJCRixNQUEzQixDQUF4QztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUVRLFFBQVEsQ0FBQ0MsTUFBVCxLQUFvQjtBQURwQjtBQURNLFNBQVAsQ0FBUDtBQUtELE9BVkQsQ0FVRSxPQUFPUCxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQTlDcUI7O0FBQUEsd0NBZ0RULE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN4QyxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTWlCLFdBQVcsR0FBRyxNQUFNYixpQkFBaUIsQ0FBQyxxQkFBRCxFQUF3QkYsTUFBeEIsQ0FBM0M7O0FBQ0EsY0FBTWdCLE9BQU8sR0FBR0MsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixTQUFuQixFQUE4QixJQUE5QixDQUFoQjs7QUFDQSxjQUFNSSxPQUFPLEdBQUdGLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsVUFBbkIsRUFBK0IsSUFBL0IsQ0FBaEI7O0FBQ0EsY0FBTUssT0FBTyxHQUFHSCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFNBQW5CLEVBQThCLElBQTlCLENBQWhCOztBQUNBLGNBQU1NLGFBQWEsR0FBR0osZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixlQUFuQixFQUFvQyxJQUFwQyxDQUF0Qjs7QUFDQSxZQUFJQyxPQUFKLEVBQWE7QUFDWCxnQkFBTTtBQUFFZCxZQUFBQTtBQUFGLGNBQXdCLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBOUI7QUFDQSxnQkFBTXdCLGNBQWMsR0FBRyxNQUFNcEIsaUJBQWlCLENBQUMsc0JBQUQsRUFBeUI7QUFDckVxQixZQUFBQSxLQUFLLEVBQUVDLGlCQUFNQyxVQUR3RDtBQUVyRXhCLFlBQUFBLElBQUksRUFBRTtBQUNKeUIsY0FBQUEsSUFBSSxFQUFFLENBREY7QUFFSkMsY0FBQUEsS0FBSyxFQUFFO0FBQ0xDLGdCQUFBQSxJQUFJLEVBQUU7QUFDSkMsa0JBQUFBLElBQUksRUFBRTtBQUNKQyxvQkFBQUEsSUFBSSxFQUFFO0FBQ0pDLHNCQUFBQSxVQUFVLEVBQUVwQjtBQURSO0FBREY7QUFERjtBQURELGVBRkg7QUFXSnFCLGNBQUFBLElBQUksRUFBRTtBQUNKQyxnQkFBQUEsWUFBWSxFQUFFO0FBQ1pDLGtCQUFBQSxLQUFLLEVBQUU7QUFDTEMsb0JBQUFBLEtBQUssRUFBRTtBQURGO0FBREssaUJBRFY7QUFNSixpQ0FBaUI7QUFDZkMsa0JBQUFBLFVBQVUsRUFBRTtBQUNWRCxvQkFBQUEsS0FBSyxFQUFFLFlBREc7QUFFVkUsb0JBQUFBLE1BQU0sRUFBRSxDQUFDO0FBQUVDLHNCQUFBQSxJQUFJLEVBQUU7QUFBUixxQkFBRDtBQUZFO0FBREc7QUFOYjtBQVhGO0FBRitELFdBQXpCLENBQTlDOztBQTRCQSxnQkFBTUMsUUFBUSxHQUFHdEIsZ0JBQUVDLEdBQUYsQ0FBTUksY0FBTixFQUFzQixnREFBdEIsRUFBd0UsQ0FBeEUsQ0FBakI7O0FBQ0EsZ0JBQU1rQixhQUFhLEdBQUd2QixnQkFBRUMsR0FBRixDQUFNSSxjQUFOLEVBQXNCLG1DQUF0QixFQUEyRCxFQUEzRCxDQUF0Qjs7QUFDQSxnQkFBTW1CLFdBQVcsR0FBR0QsYUFBYSxDQUFDRSxNQUFkLENBQ2xCLENBQUNDLEdBQUQsRUFBTUMsSUFBTixLQUFnQkEsSUFBSSxDQUFDQyxHQUFMLEtBQWEsUUFBYixHQUF3QkQsSUFBSSxDQUFDRSxTQUE3QixHQUF5Q0gsR0FEdkMsRUFFbEIsQ0FGa0IsQ0FBcEI7QUFJQSxpQkFBTzVDLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFlBQUFBLElBQUksRUFBRTtBQUFFSSxjQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZQyxjQUFBQSxJQUFJLEVBQUVVLE9BQWxCO0FBQTJCeUIsY0FBQUEsV0FBM0I7QUFBd0NGLGNBQUFBLFFBQXhDO0FBQWtEcEIsY0FBQUEsT0FBbEQ7QUFBMkRDLGNBQUFBLE9BQTNEO0FBQW9FQyxjQUFBQTtBQUFwRTtBQURNLFdBQVAsQ0FBUDtBQUdELFNBdkNELE1BdUNPO0FBQ0wsaUJBQU90QixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFDSkksY0FBQUEsRUFBRSxFQUFFO0FBREE7QUFETSxXQUFQLENBQVA7QUFLRDtBQUNGLE9BdkRELENBdURFLE9BQU9FLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyx5Q0FBZCxFQUF5REYsR0FBekQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBakhxQjs7QUFBQSwyQ0FtSE4sT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU07QUFBRW9CLFVBQUFBLE9BQUY7QUFBV0MsVUFBQUE7QUFBWCxZQUE2QnZCLEdBQUcsQ0FBQzZCLEtBQXZDO0FBQ0EsY0FBTTNCLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVELEVBQWI7QUFBaUJTLFVBQUFBLE9BQWpCO0FBQTBCQyxVQUFBQSxhQUExQjtBQUF5Q3BCLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRztBQUFuRCxTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1pRCxjQUFjLEdBQUcsTUFBTTdDLGlCQUFpQixDQUFDLHdCQUFELEVBQTJCRixNQUEzQixDQUE5QztBQUNBLGNBQU07QUFBRWdELFVBQUFBLFFBQUY7QUFBWUMsVUFBQUE7QUFBWixZQUFvQkYsY0FBMUI7QUFDQSxlQUFPaEQsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpjLFlBQUFBLE9BQU8sRUFBRTZCLFFBRkw7QUFHSnJDLFlBQUFBLEVBQUUsRUFBRXNDO0FBSEE7QUFETSxTQUFQLENBQVA7QUFPRCxPQWRELENBY0UsT0FBTzFDLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBM0lxQjs7QUFBQSx5Q0E2SVIsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDLFVBQUk7QUFDRixjQUFNO0FBQUV1QyxVQUFBQSxJQUFGO0FBQVFaLFVBQUFBLElBQVI7QUFBY3dCLFVBQUFBLE1BQWQ7QUFBc0JDLFVBQUFBLGFBQXRCO0FBQXFDQyxVQUFBQSxTQUFyQztBQUFnREMsVUFBQUE7QUFBaEQsWUFBMER2RCxHQUFHLENBQUM2QixLQUFwRTtBQUVBLFlBQUlFLElBQUksR0FBRztBQUFFeUIsVUFBQUEsU0FBUyxFQUFFO0FBQWIsU0FBWDs7QUFDQSxZQUFJSixNQUFNLENBQUNLLElBQVAsRUFBSixFQUFtQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTFCLFVBQUFBLElBQUksR0FBRztBQUNMMkIsWUFBQUEsWUFBWSxFQUFFO0FBQ1pDLGNBQUFBLGFBQWEsRUFBRSxjQURIO0FBRVpDLGNBQUFBLGdCQUFnQixFQUFFLEtBRk47QUFHWi9CLGNBQUFBLEtBQUssRUFBRyxJQUFHdUIsTUFBTSxDQUFDSyxJQUFQLEdBQWNJLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUJDLElBQXpCLENBQThCLEtBQTlCLENBQXFDO0FBSHBDO0FBRFQsV0FBUDtBQU9EOztBQUVELGNBQU1DLE1BQU0sR0FBRyxDQUFDO0FBQUUvQixVQUFBQSxJQUFJLEVBQUU7QUFBRSw0QkFBZ0I7QUFBbEI7QUFBUixTQUFELENBQWY7O0FBQ0EsWUFBSXVCLEtBQUssS0FBSyxLQUFkLEVBQXFCO0FBQ25CLGdCQUFNUyxPQUFPLEdBQUdULEtBQUssS0FBSyxTQUExQjtBQUNBUSxVQUFBQSxNQUFNLENBQUNFLElBQVAsQ0FBWTtBQUFFakMsWUFBQUEsSUFBSSxFQUFFO0FBQUUsaUNBQW1CZ0M7QUFBckI7QUFBUixXQUFaO0FBQ0Q7O0FBRUQsY0FBTUUsWUFBWSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQXJCO0FBQ0EsY0FBTUMsbUJBQW1CLEdBQUc7QUFBRXhDLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQTVCOztBQUNBLFlBQUlzQyxZQUFZLENBQUNaLFNBQUQsQ0FBaEIsRUFBNkI7QUFDM0JjLFVBQUFBLG1CQUFtQixDQUFDQyxJQUFwQixHQUEyQixDQUFDO0FBQUUsYUFBQ0gsWUFBWSxDQUFDWixTQUFELENBQWIsR0FBMkJEO0FBQTdCLFdBQUQsQ0FBM0I7QUFDQWUsVUFBQUEsbUJBQW1CLENBQUN4QyxJQUFwQixHQUEyQlQsZ0JBQUVtRCxTQUFGLENBQVkxQyxJQUFaLEVBQWtCLElBQWxCLENBQTNCO0FBQ0F3QyxVQUFBQSxtQkFBbUIsQ0FBQzVCLElBQXBCLEdBQTJCckIsZ0JBQUVtRCxTQUFGLENBQVk5QixJQUFaLEVBQWtCLENBQWxCLENBQTNCO0FBQ0Q7O0FBRUQsY0FBTXRDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUU7QUFDSm9FLFlBQUFBLG1CQUFtQixFQUFFLElBRGpCO0FBRUpsRCxZQUFBQSxPQUFPLEVBQUUsSUFGTDtBQUdKLGVBQUcrQyxtQkFIQztBQUlKdkMsWUFBQUEsS0FBSyxFQUFFO0FBQ0xDLGNBQUFBLElBQUksRUFBRTtBQUNKaUMsZ0JBQUFBLE1BREk7QUFFSmhDLGdCQUFBQTtBQUZJO0FBREQ7QUFKSDtBQURPLFNBQWY7QUFjQSxjQUFNO0FBQUUzQixVQUFBQSxpQkFBaUIsRUFBRW9FO0FBQXJCLFlBQW1ELE1BQU0sS0FBSzFFLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBL0Q7QUFDQSxjQUFNaUIsV0FBVyxHQUFHLE1BQU11RCx5QkFBeUIsQ0FBQyxzQkFBRCxFQUF5QnRFLE1BQXpCLENBQW5EOztBQUVBLGNBQU11RSxhQUFhLEdBQUd0RCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLGtCQUFuQixFQUF1QyxDQUF2QyxDQUF0Qjs7QUFDQSxjQUFNeUQscUJBQXFCLEdBQUd2RCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFdBQW5CLEVBQWdDLEVBQWhDLEVBQW9DMEQsR0FBcEMsQ0FBeUMzRCxNQUFELElBQVk7QUFDaEYsZ0JBQU07QUFDSm1DLFlBQUFBLEdBQUcsRUFBRXRDLEVBREQ7QUFFSnFDLFlBQUFBLFFBQVEsRUFBRTdCLE9BRk47QUFHSnVELFlBQUFBLE9BQU8sRUFBRXRELE9BSEw7QUFJSnVELFlBQUFBLGFBQWEsRUFBRXRELGFBSlg7QUFLSnVELFlBQUFBLE9BQU8sRUFBRTVEO0FBTEwsY0FNRkYsTUFOSjtBQU9BLGdCQUFNO0FBQUVtRCxZQUFBQSxJQUFGO0FBQVFILFlBQUFBO0FBQVIsY0FBb0I5QyxPQUExQjtBQUNBLGlCQUFPLENBQUNMLEVBQUQsRUFBSztBQUFFQSxZQUFBQSxFQUFGO0FBQU1RLFlBQUFBLE9BQU47QUFBZUMsWUFBQUEsT0FBZjtBQUF3QkMsWUFBQUEsYUFBeEI7QUFBdUM0QyxZQUFBQSxJQUF2QztBQUE2Q0gsWUFBQUEsT0FBN0M7QUFBc0Q5QyxZQUFBQTtBQUF0RCxXQUFMLENBQVA7QUFDRCxTQVY2QixFQVUzQixFQVYyQixDQUE5Qjs7QUFXQSxjQUFNNkQsVUFBVSxHQUFHLElBQUlDLEdBQUosQ0FBUU4scUJBQVIsQ0FBbkI7QUFDQSxjQUFNTyxVQUFVLEdBQUcsQ0FBQyxHQUFHRixVQUFVLENBQUNHLElBQVgsRUFBSixDQUFuQjtBQUVBLGNBQU1DLGFBQWEsR0FBRyxFQUF0QjtBQUNBLGNBQU1DLFNBQVMsR0FBRztBQUNoQkMsVUFBQUEsTUFBTSxFQUFFLFFBRFE7QUFFaEJDLFVBQUFBLFlBQVksRUFBRSxjQUZFO0FBR2hCQyxVQUFBQSxNQUFNLEVBQUUsUUFIUTtBQUloQkMsVUFBQUEsT0FBTyxFQUFFLFNBSk87QUFLaEJDLFVBQUFBLG9CQUFvQixFQUFFO0FBTE4sU0FBbEI7O0FBT0EsWUFBSUwsU0FBUyxDQUFDOUIsU0FBRCxDQUFiLEVBQTBCO0FBQ3hCNkIsVUFBQUEsYUFBYSxDQUFDTyxLQUFkLEdBQXNCO0FBQUUsYUFBQ04sU0FBUyxDQUFDOUIsU0FBRCxDQUFWLEdBQXdCRDtBQUExQixXQUF0QjtBQUNEOztBQUNELGNBQU1zQyxVQUFVLEdBQUc7QUFDakJsRSxVQUFBQSxLQUFLLEVBQUVDLGlCQUFNQyxVQURJO0FBRWpCeEIsVUFBQUEsSUFBSSxFQUFFO0FBQ0p5QixZQUFBQSxJQUFJLEVBQUUsQ0FERjtBQUVKQyxZQUFBQSxLQUFLLEVBQUU7QUFBRU8sY0FBQUEsS0FBSyxFQUFFO0FBQUVILGdCQUFBQSxVQUFVLEVBQUVnRDtBQUFkO0FBQVQsYUFGSDtBQUdKVyxZQUFBQSxZQUFZLEVBQUU7QUFDWkMsY0FBQUEsZ0JBQWdCLEVBQUU7QUFDaEJ6RCxnQkFBQUEsS0FBSyxFQUFFO0FBQ0xDLGtCQUFBQSxLQUFLLEVBQUUsWUFERjtBQUVMLHFCQUFHOEMsYUFGRTtBQUdMdkQsa0JBQUFBLElBQUksRUFBRVksSUFBSSxHQUFHWjtBQUhSLGlCQURTO0FBTWhCZ0UsZ0JBQUFBLFlBQVksRUFBRTtBQUNaUCxrQkFBQUEsTUFBTSxFQUFFO0FBQUV0QixvQkFBQUEsTUFBTSxFQUFFO0FBQUUvQixzQkFBQUEsSUFBSSxFQUFFO0FBQUV1Qix3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQURJO0FBRVorQixrQkFBQUEsWUFBWSxFQUFFO0FBQUV2QixvQkFBQUEsTUFBTSxFQUFFO0FBQUUvQixzQkFBQUEsSUFBSSxFQUFFO0FBQUV1Qix3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQUZGO0FBR1pnQyxrQkFBQUEsTUFBTSxFQUFFO0FBQUV4QixvQkFBQUEsTUFBTSxFQUFFO0FBQUUvQixzQkFBQUEsSUFBSSxFQUFFO0FBQUV1Qix3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQUhJO0FBSVppQyxrQkFBQUEsT0FBTyxFQUFFO0FBQ1B6QixvQkFBQUEsTUFBTSxFQUFFO0FBQ05qQyxzQkFBQUEsSUFBSSxFQUFFO0FBQ0ppQyx3QkFBQUEsTUFBTSxFQUFFO0FBQUUvQiwwQkFBQUEsSUFBSSxFQUFFO0FBQUV1Qiw0QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUix5QkFESjtBQUVKdUMsd0JBQUFBLFFBQVEsRUFBRTtBQUFFQywwQkFBQUEsTUFBTSxFQUFFO0FBQUUxRCw0QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBVjtBQUZOO0FBREE7QUFERCxtQkFKRztBQVlaMkQsa0JBQUFBLHNCQUFzQixFQUFFO0FBQUVDLG9CQUFBQSxHQUFHLEVBQUU7QUFBRTVELHNCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFQLG1CQVpaO0FBYVo2RCxrQkFBQUEsWUFBWSxFQUFFO0FBQ1pDLG9CQUFBQSxRQUFRLEVBQUU7QUFDUnZFLHNCQUFBQSxJQUFJLEVBQUUsQ0FERTtBQUVSeUMsc0JBQUFBLElBQUksRUFBRSxDQUFDO0FBQUUrQix3QkFBQUEsVUFBVSxFQUFFO0FBQUVWLDBCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFkLHVCQUFELENBRkU7QUFHUlosc0JBQUFBLE9BQU8sRUFBRTtBQUNQdUIsd0JBQUFBLFFBQVEsRUFBRSxDQUFDLHdCQUFELEVBQTJCLGNBQTNCO0FBREg7QUFIRDtBQURFO0FBYkY7QUFORTtBQUROO0FBSFY7QUFGVyxTQUFuQjtBQXdDQSxjQUFNO0FBQUVqRyxVQUFBQTtBQUFGLFlBQXdCLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBOUI7QUFDQSxjQUFNc0csY0FBYyxHQUFHLE1BQU1sRyxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QnVGLFVBQXpCLENBQTlDOztBQUNBLGNBQU1ZLE9BQU8sR0FBR3BGLGdCQUFFQyxHQUFGLENBQU1rRixjQUFOLEVBQXNCLHVDQUF0QixFQUErRCxFQUEvRCxFQUFtRTNCLEdBQW5FLENBQ2I2QixNQUFELElBQVk7QUFDVixnQkFBTTtBQUNKekQsWUFBQUEsR0FBRyxFQUFFbEMsRUFERDtBQUVKbUYsWUFBQUEsc0JBQXNCLEVBQUU7QUFBRVMsY0FBQUEsS0FBSyxFQUFFaEI7QUFBVCxhQUZwQjtBQUdKRCxZQUFBQSxPQUFPLEVBQUU7QUFBRXhDLGNBQUFBLFNBQVMsRUFBRXdDO0FBQWIsYUFITDtBQUlKRixZQUFBQSxZQUFZLEVBQUU7QUFBRXRDLGNBQUFBLFNBQVMsRUFBRXNDO0FBQWIsYUFKVjtBQUtKRCxZQUFBQSxNQUFNLEVBQUU7QUFBRXJDLGNBQUFBLFNBQVMsRUFBRXFDO0FBQWIsYUFMSjtBQU1KRSxZQUFBQSxNQUFNLEVBQUU7QUFBRXZDLGNBQUFBLFNBQVMsRUFBRXVDO0FBQWIsYUFOSjtBQU9KVyxZQUFBQSxZQUFZLEVBQUU7QUFDWlEsY0FBQUEsSUFBSSxFQUFFO0FBQ0pBLGdCQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFNUIsa0JBQUFBLE9BQU8sRUFBRTtBQUFFNkIsb0JBQUFBLFlBQVksRUFBRUM7QUFBaEI7QUFEWCxpQkFESTtBQURGO0FBRE07QUFQVixjQWdCRkosTUFoQko7QUFpQkEsZ0JBQU10RixPQUFPLEdBQUc2RCxVQUFVLENBQUMzRCxHQUFYLENBQWVQLEVBQWYsQ0FBaEI7QUFDQWtFLFVBQUFBLFVBQVUsQ0FBQzhCLE1BQVgsQ0FBa0JoRyxFQUFsQjtBQUNBLGlCQUFPLEVBQ0wsR0FBR0ssT0FERTtBQUVMTCxZQUFBQSxFQUZLO0FBR0w0RSxZQUFBQSxvQkFISztBQUlMRCxZQUFBQSxPQUpLO0FBS0xvQixZQUFBQSxXQUxLO0FBTUx0QixZQUFBQSxZQU5LO0FBT0xELFlBQUFBLE1BUEs7QUFRTEUsWUFBQUEsTUFSSztBQVNMdUIsWUFBQUEsV0FBVyxFQUFFQyxJQUFJLENBQUNDLEdBQUw7QUFUUixXQUFQO0FBV0QsU0FoQ2EsQ0FBaEI7O0FBbUNBLGNBQU1DLGNBQWMsR0FBRyxDQUFDLEdBQUdsQyxVQUFVLENBQUNtQyxNQUFYLEVBQUosRUFBeUJ2QyxHQUF6QixDQUE4QnpELE9BQUQsS0FBYyxFQUNoRSxHQUFHQSxPQUQ2RDtBQUVoRXVFLFVBQUFBLG9CQUFvQixFQUFFLElBRjBDO0FBR2hFRCxVQUFBQSxPQUFPLEVBQUUsQ0FIdUQ7QUFJaEVILFVBQUFBLE1BQU0sRUFBRSxDQUp3RDtBQUtoRUMsVUFBQUEsWUFBWSxFQUFFLENBTGtEO0FBTWhFQyxVQUFBQSxNQUFNLEVBQUUsQ0FOd0Q7QUFPaEVxQixVQUFBQSxXQUFXLEVBQUUsSUFQbUQ7QUFRaEVFLFVBQUFBLFdBQVcsRUFBRUMsSUFBSSxDQUFDQyxHQUFMO0FBUm1ELFNBQWQsQ0FBN0IsQ0FBdkI7O0FBV0EsWUFBSUcsT0FBTyxHQUFHaEcsZ0JBQUVpRyxPQUFGLENBQVViLE9BQU8sQ0FBQ2MsTUFBUixDQUFlSixjQUFmLENBQVYsRUFBMEMsQ0FBQzNELFNBQUQsQ0FBMUMsRUFBdUQsQ0FBQ0QsYUFBRCxDQUF2RCxDQUFkLENBbEtFLENBbUtGO0FBQ0E7QUFDQTs7O0FBQ0EsWUFBSSxDQUFDYSxZQUFZLENBQUNaLFNBQUQsQ0FBakIsRUFBOEI7QUFDNUI2RCxVQUFBQSxPQUFPLEdBQUdBLE9BQU8sQ0FBQ0csS0FBUixDQUFjOUUsSUFBZCxFQUFvQkEsSUFBSSxHQUFHWixJQUEzQixDQUFWO0FBQ0Q7O0FBRUQsZUFBTzNCLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKZ0gsWUFBQUEsUUFBUSxFQUFFSixPQUZOO0FBR0oxQyxZQUFBQTtBQUhJO0FBRE0sU0FBUCxDQUFQO0FBT0QsT0FqTEQsQ0FpTEUsT0FBT2hFLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyx5Q0FBZCxFQUF5REYsR0FBekQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBeFVxQjs7QUFBQSwrQ0EwVUYsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQy9DLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiWSxVQUFBQSxTQUFTLEVBQUVELEVBREU7QUFFYlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBRkcsU0FBZjtBQUlBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsY0FBTXdILG1CQUFtQixHQUFHLE1BQU1wSCxpQkFBaUIsQ0FBQyw0QkFBRCxFQUErQkYsTUFBL0IsQ0FBbkQ7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUNpSCxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUpsSCxZQUFBQSxJQUFJLEVBQUVnSDtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU8vRyxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQWxXcUI7O0FBQUEsNENBb1dMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTTtBQUFFMEgsVUFBQUEsTUFBTSxHQUFHO0FBQVgsWUFBc0IzSCxHQUFHLENBQUM2QixLQUFoQztBQUNBLGNBQU0zQixNQUFNLEdBQUc7QUFDYkMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHLElBREc7QUFFYndILFVBQUFBO0FBRmEsU0FBZjtBQUlBLGNBQU07QUFBRXZILFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTTRILGVBQWUsR0FBRyxNQUFNeEgsaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQS9DO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRW9IO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWRELENBY0UsT0FBT25ILEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBNVhxQjs7QUFBQSw0Q0ErWEwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNO0FBQUU0QixVQUFBQSxLQUFGO0FBQVNKLFVBQUFBLEtBQVQ7QUFBZ0JHLFVBQUFBO0FBQWhCLFlBQXlCNUIsR0FBRyxDQUFDRyxJQUFuQztBQUNBLGNBQU1ELE1BQU0sR0FBRztBQUFFdUIsVUFBQUEsS0FBRjtBQUFTRyxVQUFBQSxJQUFUO0FBQWV6QixVQUFBQSxJQUFJLEVBQUUwQjtBQUFyQixTQUFmO0FBRUEsY0FBTTtBQUFFekIsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNbUgsT0FBTyxHQUFHLE1BQU0vRyxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QkYsTUFBekIsQ0FBdkM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFMkc7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BWkQsQ0FZRSxPQUFPMUcsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0FyWnFCOztBQUNwQixTQUFLZCxRQUFMLEdBQWdCQSxRQUFoQjtBQUNEOztBQUhpQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiAgIENvcHlyaWdodCAyMDE5IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogICBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqICAgb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xuXG5pbXBvcnQgeyBJTkRFWCB9IGZyb20gJy4uLy4uL3V0aWxzL2NvbnN0YW50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vbml0b3JTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IoZXNEcml2ZXIpIHtcbiAgICB0aGlzLmVzRHJpdmVyID0gZXNEcml2ZXI7XG4gIH1cblxuICBjcmVhdGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgYm9keTogcmVxLmJvZHkgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGNyZWF0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmNyZWF0ZU1vbml0b3InLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBjcmVhdGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGNyZWF0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGRlbGV0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZGVsZXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiByZXNwb25zZS5yZXN1bHQgPT09ICdkZWxldGVkJyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGRlbGV0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldE1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBjb25zdCBtb25pdG9yID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdtb25pdG9yJywgbnVsbCk7XG4gICAgICBjb25zdCB2ZXJzaW9uID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfdmVyc2lvbicsIG51bGwpO1xuICAgICAgY29uc3QgaWZTZXFObyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3NlcV9ubycsIG51bGwpO1xuICAgICAgY29uc3QgaWZQcmltYXJ5VGVybSA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3ByaW1hcnlfdGVybScsIG51bGwpO1xuICAgICAgaWYgKG1vbml0b3IpIHtcbiAgICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgICBjb25zdCBzZWFyY2hSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9ycycsIHtcbiAgICAgICAgICBpbmRleDogSU5ERVguQUxMX0FMRVJUUyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgIG11c3Q6IHtcbiAgICAgICAgICAgICAgICAgIHRlcm06IHtcbiAgICAgICAgICAgICAgICAgICAgbW9uaXRvcl9pZDogaWQsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgICBhY3RpdmVfY291bnQ6IHtcbiAgICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGF0ZScsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgJzI0X2hvdXJfY291bnQnOiB7XG4gICAgICAgICAgICAgICAgZGF0ZV9yYW5nZToge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGFydF90aW1lJyxcbiAgICAgICAgICAgICAgICAgIHJhbmdlczogW3sgZnJvbTogJ25vdy0yNGgvaCcgfV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGRheUNvdW50ID0gXy5nZXQoc2VhcmNoUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMuMjRfaG91cl9jb3VudC5idWNrZXRzLjAuZG9jX2NvdW50JywgMCk7XG4gICAgICAgIGNvbnN0IGFjdGl2ZUJ1Y2tldHMgPSBfLmdldChzZWFyY2hSZXNwb25zZSwgJ2FnZ3JlZ2F0aW9ucy5hY3RpdmVfY291bnQuYnVja2V0cycsIFtdKTtcbiAgICAgICAgY29uc3QgYWN0aXZlQ291bnQgPSBhY3RpdmVCdWNrZXRzLnJlZHVjZShcbiAgICAgICAgICAoYWNjLCBjdXJyKSA9PiAoY3Vyci5rZXkgPT09ICdBQ1RJVkUnID8gY3Vyci5kb2NfY291bnQgOiBhY2MpLFxuICAgICAgICAgIDBcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogdHJ1ZSwgcmVzcDogbW9uaXRvciwgYWN0aXZlQ291bnQsIGRheUNvdW50LCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHVwZGF0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHsgaWZTZXFObywgaWZQcmltYXJ5VGVybSB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgY29uc3QgcGFyYW1zID0geyBtb25pdG9ySWQ6IGlkLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtLCBib2R5OiByZXEuYm9keSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgdXBkYXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcudXBkYXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBjb25zdCB7IF92ZXJzaW9uLCBfaWQgfSA9IHVwZGF0ZVJlc3BvbnNlO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICB2ZXJzaW9uOiBfdmVyc2lvbixcbiAgICAgICAgICBpZDogX2lkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gdXBkYXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0TW9uaXRvcnMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBmcm9tLCBzaXplLCBzZWFyY2gsIHNvcnREaXJlY3Rpb24sIHNvcnRGaWVsZCwgc3RhdGUgfSA9IHJlcS5xdWVyeTtcblxuICAgICAgbGV0IG11c3QgPSB7IG1hdGNoX2FsbDoge30gfTtcbiAgICAgIGlmIChzZWFyY2gudHJpbSgpKSB7XG4gICAgICAgIC8vIFRoaXMgaXMgYW4gZXhwZW5zaXZlIHdpbGRjYXJkIHF1ZXJ5IHRvIG1hdGNoIG1vbml0b3IgbmFtZXMgc3VjaCBhczogXCJUaGlzIGlzIGEgbG9uZyBtb25pdG9yIG5hbWVcIlxuICAgICAgICAvLyBzZWFyY2ggcXVlcnkgPT4gXCJsb25nIG1vbml0XCJcbiAgICAgICAgLy8gVGhpcyBpcyBhY2NlcHRhYmxlIGJlY2F1c2Ugd2Ugd2lsbCBuZXZlciBhbGxvdyBtb3JlIHRoYW4gMSwwMDAgbW9uaXRvcnNcbiAgICAgICAgbXVzdCA9IHtcbiAgICAgICAgICBxdWVyeV9zdHJpbmc6IHtcbiAgICAgICAgICAgIGRlZmF1bHRfZmllbGQ6ICdtb25pdG9yLm5hbWUnLFxuICAgICAgICAgICAgZGVmYXVsdF9vcGVyYXRvcjogJ0FORCcsXG4gICAgICAgICAgICBxdWVyeTogYCoke3NlYXJjaC50cmltKCkuc3BsaXQoJyAnKS5qb2luKCcqIConKX0qYCxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICBjb25zdCBmaWx0ZXIgPSBbeyB0ZXJtOiB7ICdtb25pdG9yLnR5cGUnOiAnbW9uaXRvcicgfSB9XTtcbiAgICAgIGlmIChzdGF0ZSAhPT0gJ2FsbCcpIHtcbiAgICAgICAgY29uc3QgZW5hYmxlZCA9IHN0YXRlID09PSAnZW5hYmxlZCc7XG4gICAgICAgIGZpbHRlci5wdXNoKHsgdGVybTogeyAnbW9uaXRvci5lbmFibGVkJzogZW5hYmxlZCB9IH0pO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBtb25pdG9yU29ydHMgPSB7IG5hbWU6ICdtb25pdG9yLm5hbWUua2V5d29yZCcgfTtcbiAgICAgIGNvbnN0IG1vbml0b3JTb3J0UGFnZURhdGEgPSB7IHNpemU6IDEwMDAgfTtcbiAgICAgIGlmIChtb25pdG9yU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNvcnQgPSBbeyBbbW9uaXRvclNvcnRzW3NvcnRGaWVsZF1dOiBzb3J0RGlyZWN0aW9uIH1dO1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNpemUgPSBfLmRlZmF1bHRUbyhzaXplLCAxMDAwKTtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5mcm9tID0gXy5kZWZhdWx0VG8oZnJvbSwgMCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNlcV9ub19wcmltYXJ5X3Rlcm06IHRydWUsXG4gICAgICAgICAgdmVyc2lvbjogdHJ1ZSxcbiAgICAgICAgICAuLi5tb25pdG9yU29ydFBhZ2VEYXRhLFxuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgIGZpbHRlcixcbiAgICAgICAgICAgICAgbXVzdCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGdldFJlc3BvbnNlID0gYXdhaXQgYWxlcnRpbmdDYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBwYXJhbXMpO1xuXG4gICAgICBjb25zdCB0b3RhbE1vbml0b3JzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdoaXRzLnRvdGFsLnZhbHVlJywgMCk7XG4gICAgICBjb25zdCBtb25pdG9yS2V5VmFsdWVUdXBsZXMgPSBfLmdldChnZXRSZXNwb25zZSwgJ2hpdHMuaGl0cycsIFtdKS5tYXAoKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgICBfdmVyc2lvbjogdmVyc2lvbixcbiAgICAgICAgICBfc2VxX25vOiBpZlNlcU5vLFxuICAgICAgICAgIF9wcmltYXJ5X3Rlcm06IGlmUHJpbWFyeVRlcm0sXG4gICAgICAgICAgX3NvdXJjZTogbW9uaXRvcixcbiAgICAgICAgfSA9IHJlc3VsdDtcbiAgICAgICAgY29uc3QgeyBuYW1lLCBlbmFibGVkIH0gPSBtb25pdG9yO1xuICAgICAgICByZXR1cm4gW2lkLCB7IGlkLCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtLCBuYW1lLCBlbmFibGVkLCBtb25pdG9yIH1dO1xuICAgICAgfSwge30pO1xuICAgICAgY29uc3QgbW9uaXRvck1hcCA9IG5ldyBNYXAobW9uaXRvcktleVZhbHVlVHVwbGVzKTtcbiAgICAgIGNvbnN0IG1vbml0b3JJZHMgPSBbLi4ubW9uaXRvck1hcC5rZXlzKCldO1xuXG4gICAgICBjb25zdCBhZ2dzT3JkZXJEYXRhID0ge307XG4gICAgICBjb25zdCBhZ2dzU29ydHMgPSB7XG4gICAgICAgIGFjdGl2ZTogJ2FjdGl2ZScsXG4gICAgICAgIGFja25vd2xlZGdlZDogJ2Fja25vd2xlZGdlZCcsXG4gICAgICAgIGVycm9yczogJ2Vycm9ycycsXG4gICAgICAgIGlnbm9yZWQ6ICdpZ25vcmVkJyxcbiAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWU6ICdsYXN0X25vdGlmaWNhdGlvbl90aW1lJyxcbiAgICAgIH07XG4gICAgICBpZiAoYWdnc1NvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgYWdnc09yZGVyRGF0YS5vcmRlciA9IHsgW2FnZ3NTb3J0c1tzb3J0RmllbGRdXTogc29ydERpcmVjdGlvbiB9O1xuICAgICAgfVxuICAgICAgY29uc3QgYWdnc1BhcmFtcyA9IHtcbiAgICAgICAgaW5kZXg6IElOREVYLkFMTF9BTEVSVFMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgIHF1ZXJ5OiB7IHRlcm1zOiB7IG1vbml0b3JfaWQ6IG1vbml0b3JJZHMgfSB9LFxuICAgICAgICAgIGFnZ3JlZ2F0aW9uczoge1xuICAgICAgICAgICAgdW5pcV9tb25pdG9yX2lkczoge1xuICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgIGZpZWxkOiAnbW9uaXRvcl9pZCcsXG4gICAgICAgICAgICAgICAgLi4uYWdnc09yZGVyRGF0YSxcbiAgICAgICAgICAgICAgICBzaXplOiBmcm9tICsgc2l6ZSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICAgICAgYWN0aXZlOiB7IGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQUNUSVZFJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBhY2tub3dsZWRnZWQ6IHsgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdBQ0tOT1dMRURHRUQnIH0gfSB9LFxuICAgICAgICAgICAgICAgIGVycm9yczogeyBmaWx0ZXI6IHsgdGVybTogeyBzdGF0ZTogJ0VSUk9SJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBpZ25vcmVkOiB7XG4gICAgICAgICAgICAgICAgICBmaWx0ZXI6IHtcbiAgICAgICAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQ09NUExFVEVEJyB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgbXVzdF9ub3Q6IHsgZXhpc3RzOiB7IGZpZWxkOiAnYWNrbm93bGVkZ2VkX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IG1heDogeyBmaWVsZDogJ2xhc3Rfbm90aWZpY2F0aW9uX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICBsYXRlc3RfYWxlcnQ6IHtcbiAgICAgICAgICAgICAgICAgIHRvcF9oaXRzOiB7XG4gICAgICAgICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgICAgICAgIHNvcnQ6IFt7IHN0YXJ0X3RpbWU6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgaW5jbHVkZXM6IFsnbGFzdF9ub3RpZmljYXRpb25fdGltZScsICd0cmlnZ2VyX25hbWUnXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGVzQWdnc1Jlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgYWdnc1BhcmFtcyk7XG4gICAgICBjb25zdCBidWNrZXRzID0gXy5nZXQoZXNBZ2dzUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMudW5pcV9tb25pdG9yX2lkcy5idWNrZXRzJywgW10pLm1hcChcbiAgICAgICAgKGJ1Y2tldCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGtleTogaWQsXG4gICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IHZhbHVlOiBsYXN0Tm90aWZpY2F0aW9uVGltZSB9LFxuICAgICAgICAgICAgaWdub3JlZDogeyBkb2NfY291bnQ6IGlnbm9yZWQgfSxcbiAgICAgICAgICAgIGFja25vd2xlZGdlZDogeyBkb2NfY291bnQ6IGFja25vd2xlZGdlZCB9LFxuICAgICAgICAgICAgYWN0aXZlOiB7IGRvY19jb3VudDogYWN0aXZlIH0sXG4gICAgICAgICAgICBlcnJvcnM6IHsgZG9jX2NvdW50OiBlcnJvcnMgfSxcbiAgICAgICAgICAgIGxhdGVzdF9hbGVydDoge1xuICAgICAgICAgICAgICBoaXRzOiB7XG4gICAgICAgICAgICAgICAgaGl0czogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7IHRyaWdnZXJfbmFtZTogbGF0ZXN0QWxlcnQgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSA9IGJ1Y2tldDtcbiAgICAgICAgICBjb25zdCBtb25pdG9yID0gbW9uaXRvck1hcC5nZXQoaWQpO1xuICAgICAgICAgIG1vbml0b3JNYXAuZGVsZXRlKGlkKTtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWUsXG4gICAgICAgICAgICBpZ25vcmVkLFxuICAgICAgICAgICAgbGF0ZXN0QWxlcnQsXG4gICAgICAgICAgICBhY2tub3dsZWRnZWQsXG4gICAgICAgICAgICBhY3RpdmUsXG4gICAgICAgICAgICBlcnJvcnMsXG4gICAgICAgICAgICBjdXJyZW50VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICApO1xuXG4gICAgICBjb25zdCB1bnVzZWRNb25pdG9ycyA9IFsuLi5tb25pdG9yTWFwLnZhbHVlcygpXS5tYXAoKG1vbml0b3IpID0+ICh7XG4gICAgICAgIC4uLm1vbml0b3IsXG4gICAgICAgIGxhc3ROb3RpZmljYXRpb25UaW1lOiBudWxsLFxuICAgICAgICBpZ25vcmVkOiAwLFxuICAgICAgICBhY3RpdmU6IDAsXG4gICAgICAgIGFja25vd2xlZGdlZDogMCxcbiAgICAgICAgZXJyb3JzOiAwLFxuICAgICAgICBsYXRlc3RBbGVydDogJy0tJyxcbiAgICAgICAgY3VycmVudFRpbWU6IERhdGUubm93KCksXG4gICAgICB9KSk7XG5cbiAgICAgIGxldCByZXN1bHRzID0gXy5vcmRlckJ5KGJ1Y2tldHMuY29uY2F0KHVudXNlZE1vbml0b3JzKSwgW3NvcnRGaWVsZF0sIFtzb3J0RGlyZWN0aW9uXSk7XG4gICAgICAvLyBJZiB3ZSBzb3J0ZWQgb24gbW9uaXRvciBuYW1lIHRoZW4gd2UgYWxyZWFkeSBhcHBsaWVkIGZyb20vc2l6ZSB0byB0aGUgZmlyc3QgcXVlcnkgdG8gbGltaXQgd2hhdCB3ZSdyZSBhZ2dyZWdhdGluZyBvdmVyXG4gICAgICAvLyBUaGVyZWZvcmUgd2UgZG8gbm90IG5lZWQgdG8gYXBwbHkgZnJvbS9zaXplIHRvIHRoaXMgcmVzdWx0IHNldFxuICAgICAgLy8gSWYgd2Ugc29ydGVkIG9uIGFnZ3JlZ2F0aW9ucywgdGhlbiB0aGlzIGlzIG91ciBpbiBtZW1vcnkgcGFnaW5hdGlvblxuICAgICAgaWYgKCFtb25pdG9yU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICByZXN1bHRzID0gcmVzdWx0cy5zbGljZShmcm9tLCBmcm9tICsgc2l6ZSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgbW9uaXRvcnM6IHJlc3VsdHMsXG4gICAgICAgICAgdG90YWxNb25pdG9ycyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldE1vbml0b3JzJywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGFja25vd2xlZGdlQWxlcnRzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIG1vbml0b3JJZDogaWQsXG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGFja25vd2xlZGdlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuYWNrbm93bGVkZ2VBbGVydHMnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogIWFja25vd2xlZGdlUmVzcG9uc2UuZmFpbGVkLmxlbmd0aCxcbiAgICAgICAgICByZXNwOiBhY2tub3dsZWRnZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gYWNrbm93bGVkZ2VBbGVydHM6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGV4ZWN1dGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZHJ5cnVuID0gJ3RydWUnIH0gPSByZXEucXVlcnk7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgICBkcnlydW4sXG4gICAgICB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZXhlY3V0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmV4ZWN1dGVNb25pdG9yJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogZXhlY3V0ZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZXhlY3V0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIC8vVE9ETzogVGhpcyBpcyB0ZW1wb3JhcmlseSBhIHBhc3MgdGhyb3VnaCBjYWxsIHdoaWNoIG5lZWRzIHRvIGJlIGRlcHJlY2F0ZWRcbiAgc2VhcmNoTW9uaXRvcnMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBxdWVyeSwgaW5kZXgsIHNpemUgfSA9IHJlcS5ib2R5O1xuICAgICAgY29uc3QgcGFyYW1zID0geyBpbmRleCwgc2l6ZSwgYm9keTogcXVlcnkgfTtcblxuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9ycycsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IHJlc3VsdHMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBzZWFyY2hNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn1cbiJdfQ==