"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *   Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class AlertService {
  constructor(esDriver) {
    _defineProperty(this, "getAlerts", async (context, req, res) => {
      const {
        from = 0,
        size = 20,
        search = '',
        sortDirection = 'desc',
        sortField = 'start_time',
        severityLevel = 'ALL',
        alertState = 'ALL',
        monitorIds = []
      } = req.query;
      var params;

      switch (sortField) {
        case 'monitor_name':
          params = {
            sortString: `${sortField}.keyword`,
            sortOrder: sortDirection
          };
          break;

        case 'trigger_name':
          params = {
            sortString: `${sortField}.keyword`,
            sortOrder: sortDirection
          };
          break;

        case 'start_time':
          params = {
            sortString: sortField,
            sortOrder: sortDirection
          };
          break;

        case 'end_time':
          params = {
            sortString: sortField,
            sortOrder: sortDirection,
            missing: sortDirection === 'asc' ? '_last' : '_first'
          };
          break;

        case 'acknowledged_time':
          params = {
            sortString: sortField,
            sortOrder: sortDirection,
            missing: '_last'
          };
          break;
      }

      params.startIndex = from;
      params.size = size;
      params.severityLevel = severityLevel;
      params.alertState = alertState;
      params.searchString = search;
      if (search.trim()) params.searchString = `*${search.trim().split(' ').join('* *')}*`;
      if (monitorIds.length > 0) params.monitorId = !Array.isArray(monitorIds) ? monitorIds : monitorIds[0];
      const {
        callAsCurrentUser
      } = this.esDriver.asScoped(req);

      try {
        const resp = await callAsCurrentUser('alerting.getAlerts', params);
        const alerts = resp.alerts.map(hit => {
          const alert = hit;
          const id = hit.alert_id;
          const version = hit.alert_version;
          return {
            id,
            ...alert,
            version
          };
        });
        const totalAlerts = resp.totalAlerts;
        return res.ok({
          body: {
            ok: true,
            alerts,
            totalAlerts
          }
        });
      } catch (err) {
        console.log(err.message);
        return res.ok({
          body: {
            ok: false,
            err: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = AlertService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFsZXJ0U2VydmljZS5qcyJdLCJuYW1lcyI6WyJBbGVydFNlcnZpY2UiLCJjb25zdHJ1Y3RvciIsImVzRHJpdmVyIiwiY29udGV4dCIsInJlcSIsInJlcyIsImZyb20iLCJzaXplIiwic2VhcmNoIiwic29ydERpcmVjdGlvbiIsInNvcnRGaWVsZCIsInNldmVyaXR5TGV2ZWwiLCJhbGVydFN0YXRlIiwibW9uaXRvcklkcyIsInF1ZXJ5IiwicGFyYW1zIiwic29ydFN0cmluZyIsInNvcnRPcmRlciIsIm1pc3NpbmciLCJzdGFydEluZGV4Iiwic2VhcmNoU3RyaW5nIiwidHJpbSIsInNwbGl0Iiwiam9pbiIsImxlbmd0aCIsIm1vbml0b3JJZCIsIkFycmF5IiwiaXNBcnJheSIsImNhbGxBc0N1cnJlbnRVc2VyIiwiYXNTY29wZWQiLCJyZXNwIiwiYWxlcnRzIiwibWFwIiwiaGl0IiwiYWxlcnQiLCJpZCIsImFsZXJ0X2lkIiwidmVyc2lvbiIsImFsZXJ0X3ZlcnNpb24iLCJ0b3RhbEFsZXJ0cyIsIm9rIiwiYm9keSIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJtZXNzYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7QUFlZSxNQUFNQSxZQUFOLENBQW1CO0FBQ2hDQyxFQUFBQSxXQUFXLENBQUNDLFFBQUQsRUFBVztBQUFBLHVDQUlWLE9BQU9DLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN2QyxZQUFNO0FBQ0pDLFFBQUFBLElBQUksR0FBRyxDQURIO0FBRUpDLFFBQUFBLElBQUksR0FBRyxFQUZIO0FBR0pDLFFBQUFBLE1BQU0sR0FBRyxFQUhMO0FBSUpDLFFBQUFBLGFBQWEsR0FBRyxNQUpaO0FBS0pDLFFBQUFBLFNBQVMsR0FBRyxZQUxSO0FBTUpDLFFBQUFBLGFBQWEsR0FBRyxLQU5aO0FBT0pDLFFBQUFBLFVBQVUsR0FBRyxLQVBUO0FBUUpDLFFBQUFBLFVBQVUsR0FBRztBQVJULFVBU0ZULEdBQUcsQ0FBQ1UsS0FUUjtBQVdBLFVBQUlDLE1BQUo7O0FBQ0EsY0FBUUwsU0FBUjtBQUNFLGFBQUssY0FBTDtBQUNFSyxVQUFBQSxNQUFNLEdBQUc7QUFDUEMsWUFBQUEsVUFBVSxFQUFHLEdBQUVOLFNBQVUsVUFEbEI7QUFFUE8sWUFBQUEsU0FBUyxFQUFFUjtBQUZKLFdBQVQ7QUFJQTs7QUFDRixhQUFLLGNBQUw7QUFDRU0sVUFBQUEsTUFBTSxHQUFHO0FBQ1BDLFlBQUFBLFVBQVUsRUFBRyxHQUFFTixTQUFVLFVBRGxCO0FBRVBPLFlBQUFBLFNBQVMsRUFBRVI7QUFGSixXQUFUO0FBSUE7O0FBQ0YsYUFBSyxZQUFMO0FBQ0VNLFVBQUFBLE1BQU0sR0FBRztBQUNQQyxZQUFBQSxVQUFVLEVBQUVOLFNBREw7QUFFUE8sWUFBQUEsU0FBUyxFQUFFUjtBQUZKLFdBQVQ7QUFJQTs7QUFDRixhQUFLLFVBQUw7QUFDRU0sVUFBQUEsTUFBTSxHQUFHO0FBQ1BDLFlBQUFBLFVBQVUsRUFBRU4sU0FETDtBQUVQTyxZQUFBQSxTQUFTLEVBQUVSLGFBRko7QUFHUFMsWUFBQUEsT0FBTyxFQUFFVCxhQUFhLEtBQUssS0FBbEIsR0FBMEIsT0FBMUIsR0FBb0M7QUFIdEMsV0FBVDtBQUtBOztBQUNGLGFBQUssbUJBQUw7QUFDRU0sVUFBQUEsTUFBTSxHQUFHO0FBQ1BDLFlBQUFBLFVBQVUsRUFBRU4sU0FETDtBQUVQTyxZQUFBQSxTQUFTLEVBQUVSLGFBRko7QUFHUFMsWUFBQUEsT0FBTyxFQUFFO0FBSEYsV0FBVDtBQUtBO0FBaENKOztBQW1DQUgsTUFBQUEsTUFBTSxDQUFDSSxVQUFQLEdBQW9CYixJQUFwQjtBQUNBUyxNQUFBQSxNQUFNLENBQUNSLElBQVAsR0FBY0EsSUFBZDtBQUNBUSxNQUFBQSxNQUFNLENBQUNKLGFBQVAsR0FBdUJBLGFBQXZCO0FBQ0FJLE1BQUFBLE1BQU0sQ0FBQ0gsVUFBUCxHQUFvQkEsVUFBcEI7QUFDQUcsTUFBQUEsTUFBTSxDQUFDSyxZQUFQLEdBQXNCWixNQUF0QjtBQUNBLFVBQUlBLE1BQU0sQ0FBQ2EsSUFBUCxFQUFKLEVBQW1CTixNQUFNLENBQUNLLFlBQVAsR0FBdUIsSUFBR1osTUFBTSxDQUFDYSxJQUFQLEdBQWNDLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUJDLElBQXpCLENBQThCLEtBQTlCLENBQXFDLEdBQS9EO0FBQ25CLFVBQUlWLFVBQVUsQ0FBQ1csTUFBWCxHQUFvQixDQUF4QixFQUNFVCxNQUFNLENBQUNVLFNBQVAsR0FBbUIsQ0FBQ0MsS0FBSyxDQUFDQyxPQUFOLENBQWNkLFVBQWQsQ0FBRCxHQUE2QkEsVUFBN0IsR0FBMENBLFVBQVUsQ0FBQyxDQUFELENBQXZFO0FBRUYsWUFBTTtBQUFFZSxRQUFBQTtBQUFGLFVBQXdCLEtBQUsxQixRQUFMLENBQWMyQixRQUFkLENBQXVCekIsR0FBdkIsQ0FBOUI7O0FBQ0EsVUFBSTtBQUNGLGNBQU0wQixJQUFJLEdBQUcsTUFBTUYsaUJBQWlCLENBQUMsb0JBQUQsRUFBdUJiLE1BQXZCLENBQXBDO0FBQ0EsY0FBTWdCLE1BQU0sR0FBR0QsSUFBSSxDQUFDQyxNQUFMLENBQVlDLEdBQVosQ0FBaUJDLEdBQUQsSUFBUztBQUN0QyxnQkFBTUMsS0FBSyxHQUFHRCxHQUFkO0FBQ0EsZ0JBQU1FLEVBQUUsR0FBR0YsR0FBRyxDQUFDRyxRQUFmO0FBQ0EsZ0JBQU1DLE9BQU8sR0FBR0osR0FBRyxDQUFDSyxhQUFwQjtBQUNBLGlCQUFPO0FBQUVILFlBQUFBLEVBQUY7QUFBTSxlQUFHRCxLQUFUO0FBQWdCRyxZQUFBQTtBQUFoQixXQUFQO0FBQ0QsU0FMYyxDQUFmO0FBTUEsY0FBTUUsV0FBVyxHQUFHVCxJQUFJLENBQUNTLFdBQXpCO0FBRUEsZUFBT2xDLEdBQUcsQ0FBQ21DLEVBQUosQ0FBTztBQUNaQyxVQUFBQSxJQUFJLEVBQUU7QUFDSkQsWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSlQsWUFBQUEsTUFGSTtBQUdKUSxZQUFBQTtBQUhJO0FBRE0sU0FBUCxDQUFQO0FBT0QsT0FqQkQsQ0FpQkUsT0FBT0csR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRixHQUFHLENBQUNHLE9BQWhCO0FBQ0EsZUFBT3hDLEdBQUcsQ0FBQ21DLEVBQUosQ0FBTztBQUNaQyxVQUFBQSxJQUFJLEVBQUU7QUFDSkQsWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkUsWUFBQUEsR0FBRyxFQUFFQSxHQUFHLENBQUNHO0FBRkw7QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBeEZxQjs7QUFDcEIsU0FBSzNDLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0Q7O0FBSCtCIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IDIwMTkgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFsZXJ0U2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKGVzRHJpdmVyKSB7XG4gICAgdGhpcy5lc0RyaXZlciA9IGVzRHJpdmVyO1xuICB9XG5cbiAgZ2V0QWxlcnRzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgZnJvbSA9IDAsXG4gICAgICBzaXplID0gMjAsXG4gICAgICBzZWFyY2ggPSAnJyxcbiAgICAgIHNvcnREaXJlY3Rpb24gPSAnZGVzYycsXG4gICAgICBzb3J0RmllbGQgPSAnc3RhcnRfdGltZScsXG4gICAgICBzZXZlcml0eUxldmVsID0gJ0FMTCcsXG4gICAgICBhbGVydFN0YXRlID0gJ0FMTCcsXG4gICAgICBtb25pdG9ySWRzID0gW10sXG4gICAgfSA9IHJlcS5xdWVyeTtcblxuICAgIHZhciBwYXJhbXM7XG4gICAgc3dpdGNoIChzb3J0RmllbGQpIHtcbiAgICAgIGNhc2UgJ21vbml0b3JfbmFtZSc6XG4gICAgICAgIHBhcmFtcyA9IHtcbiAgICAgICAgICBzb3J0U3RyaW5nOiBgJHtzb3J0RmllbGR9LmtleXdvcmRgLFxuICAgICAgICAgIHNvcnRPcmRlcjogc29ydERpcmVjdGlvbixcbiAgICAgICAgfTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICd0cmlnZ2VyX25hbWUnOlxuICAgICAgICBwYXJhbXMgPSB7XG4gICAgICAgICAgc29ydFN0cmluZzogYCR7c29ydEZpZWxkfS5rZXl3b3JkYCxcbiAgICAgICAgICBzb3J0T3JkZXI6IHNvcnREaXJlY3Rpb24sXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnc3RhcnRfdGltZSc6XG4gICAgICAgIHBhcmFtcyA9IHtcbiAgICAgICAgICBzb3J0U3RyaW5nOiBzb3J0RmllbGQsXG4gICAgICAgICAgc29ydE9yZGVyOiBzb3J0RGlyZWN0aW9uLFxuICAgICAgICB9O1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2VuZF90aW1lJzpcbiAgICAgICAgcGFyYW1zID0ge1xuICAgICAgICAgIHNvcnRTdHJpbmc6IHNvcnRGaWVsZCxcbiAgICAgICAgICBzb3J0T3JkZXI6IHNvcnREaXJlY3Rpb24sXG4gICAgICAgICAgbWlzc2luZzogc29ydERpcmVjdGlvbiA9PT0gJ2FzYycgPyAnX2xhc3QnIDogJ19maXJzdCcsXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnYWNrbm93bGVkZ2VkX3RpbWUnOlxuICAgICAgICBwYXJhbXMgPSB7XG4gICAgICAgICAgc29ydFN0cmluZzogc29ydEZpZWxkLFxuICAgICAgICAgIHNvcnRPcmRlcjogc29ydERpcmVjdGlvbixcbiAgICAgICAgICBtaXNzaW5nOiAnX2xhc3QnLFxuICAgICAgICB9O1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICBwYXJhbXMuc3RhcnRJbmRleCA9IGZyb207XG4gICAgcGFyYW1zLnNpemUgPSBzaXplO1xuICAgIHBhcmFtcy5zZXZlcml0eUxldmVsID0gc2V2ZXJpdHlMZXZlbDtcbiAgICBwYXJhbXMuYWxlcnRTdGF0ZSA9IGFsZXJ0U3RhdGU7XG4gICAgcGFyYW1zLnNlYXJjaFN0cmluZyA9IHNlYXJjaDtcbiAgICBpZiAoc2VhcmNoLnRyaW0oKSkgcGFyYW1zLnNlYXJjaFN0cmluZyA9IGAqJHtzZWFyY2gudHJpbSgpLnNwbGl0KCcgJykuam9pbignKiAqJyl9KmA7XG4gICAgaWYgKG1vbml0b3JJZHMubGVuZ3RoID4gMClcbiAgICAgIHBhcmFtcy5tb25pdG9ySWQgPSAhQXJyYXkuaXNBcnJheShtb25pdG9ySWRzKSA/IG1vbml0b3JJZHMgOiBtb25pdG9ySWRzWzBdO1xuXG4gICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldEFsZXJ0cycsIHBhcmFtcyk7XG4gICAgICBjb25zdCBhbGVydHMgPSByZXNwLmFsZXJ0cy5tYXAoKGhpdCkgPT4ge1xuICAgICAgICBjb25zdCBhbGVydCA9IGhpdDtcbiAgICAgICAgY29uc3QgaWQgPSBoaXQuYWxlcnRfaWQ7XG4gICAgICAgIGNvbnN0IHZlcnNpb24gPSBoaXQuYWxlcnRfdmVyc2lvbjtcbiAgICAgICAgcmV0dXJuIHsgaWQsIC4uLmFsZXJ0LCB2ZXJzaW9uIH07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHRvdGFsQWxlcnRzID0gcmVzcC50b3RhbEFsZXJ0cztcblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICBhbGVydHMsXG4gICAgICAgICAgdG90YWxBbGVydHMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUubG9nKGVyci5tZXNzYWdlKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIGVycjogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG59XG4iXX0=