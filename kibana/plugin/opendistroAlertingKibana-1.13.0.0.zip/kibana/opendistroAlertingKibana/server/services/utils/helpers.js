"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.mapKeysDeep = mapKeysDeep;
exports.toCamel = exports.toSnake = void 0;

var _lodash = require("lodash");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function mapKeysDeep(obj, fn) {
  if (Array.isArray(obj)) {
    return (0, _lodash.map)(obj, innerObj => mapKeysDeep(innerObj, fn));
  } else {
    return (0, _lodash.isPlainObject)(obj) ? (0, _lodash.mapValues)((0, _lodash.mapKeys)(obj, fn), value => mapKeysDeep(value, fn)) : obj;
  }
}

const toSnake = (value, key) => (0, _lodash.snakeCase)(key);

exports.toSnake = toSnake;

const toCamel = (value, key) => (0, _lodash.camelCase)(key);

exports.toCamel = toCamel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbHBlcnMuanMiXSwibmFtZXMiOlsibWFwS2V5c0RlZXAiLCJvYmoiLCJmbiIsIkFycmF5IiwiaXNBcnJheSIsImlubmVyT2JqIiwidmFsdWUiLCJ0b1NuYWtlIiwia2V5IiwidG9DYW1lbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFlQTs7QUFmQTs7Ozs7Ozs7Ozs7Ozs7QUFpQk8sU0FBU0EsV0FBVCxDQUFxQkMsR0FBckIsRUFBMEJDLEVBQTFCLEVBQThCO0FBQ25DLE1BQUlDLEtBQUssQ0FBQ0MsT0FBTixDQUFjSCxHQUFkLENBQUosRUFBd0I7QUFDdEIsV0FBTyxpQkFBSUEsR0FBSixFQUFTSSxRQUFRLElBQUlMLFdBQVcsQ0FBQ0ssUUFBRCxFQUFXSCxFQUFYLENBQWhDLENBQVA7QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPLDJCQUFjRCxHQUFkLElBQXFCLHVCQUFVLHFCQUFRQSxHQUFSLEVBQWFDLEVBQWIsQ0FBVixFQUE0QkksS0FBSyxJQUFJTixXQUFXLENBQUNNLEtBQUQsRUFBUUosRUFBUixDQUFoRCxDQUFyQixHQUFvRkQsR0FBM0Y7QUFDRDtBQUNGOztBQUVNLE1BQU1NLE9BQU8sR0FBRyxDQUFDRCxLQUFELEVBQVFFLEdBQVIsS0FBZ0IsdUJBQVVBLEdBQVYsQ0FBaEM7Ozs7QUFFQSxNQUFNQyxPQUFPLEdBQUcsQ0FBQ0gsS0FBRCxFQUFRRSxHQUFSLEtBQWdCLHVCQUFVQSxHQUFWLENBQWhDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IDIwMjAgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IG1hcCwgbWFwS2V5cywgbWFwVmFsdWVzLCBpc1BsYWluT2JqZWN0LCBzbmFrZUNhc2UsIGNhbWVsQ2FzZSB9IGZyb20gJ2xvZGFzaCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYXBLZXlzRGVlcChvYmosIGZuKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KG9iaikpIHtcbiAgICByZXR1cm4gbWFwKG9iaiwgaW5uZXJPYmogPT4gbWFwS2V5c0RlZXAoaW5uZXJPYmosIGZuKSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGlzUGxhaW5PYmplY3Qob2JqKSA/IG1hcFZhbHVlcyhtYXBLZXlzKG9iaiwgZm4pLCB2YWx1ZSA9PiBtYXBLZXlzRGVlcCh2YWx1ZSwgZm4pKSA6IG9iajtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgdG9TbmFrZSA9ICh2YWx1ZSwga2V5KSA9PiBzbmFrZUNhc2Uoa2V5KTtcblxuZXhwb3J0IGNvbnN0IHRvQ2FtZWwgPSAodmFsdWUsIGtleSkgPT4gY2FtZWxDYXNlKGtleSk7XG4iXX0=