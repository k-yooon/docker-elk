"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *   Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class ElasticsearchService {
  constructor(esDriver) {
    _defineProperty(this, "search", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('search', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - ElasticsearchService - search', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getIndices", async (context, req, res) => {
      try {
        const {
          index
        } = req.body;
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const indices = await callAsCurrentUser('cat.indices', {
          index,
          format: 'json',
          h: 'health,index,status'
        });
        return res.ok({
          body: {
            ok: true,
            resp: indices
          }
        });
      } catch (err) {
        // Elasticsearch throws an index_not_found_exception which we'll treat as a success
        if (err.statusCode === 404) {
          return res.ok({
            body: {
              ok: true,
              resp: []
            }
          });
        } else {
          console.error('Alerting - ElasticsearchService - getIndices:', err);
          return res.ok({
            body: {
              ok: false,
              resp: err.message
            }
          });
        }
      }
    });

    _defineProperty(this, "getAliases", async (context, req, res) => {
      try {
        const {
          alias
        } = req.body;
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const aliases = await callAsCurrentUser('cat.aliases', {
          alias,
          format: 'json',
          h: 'alias,index'
        });
        return res.ok({
          body: {
            ok: true,
            resp: aliases
          }
        });
      } catch (err) {
        console.error('Alerting - ElasticsearchService - getAliases:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMappings", async (context, req, res) => {
      try {
        const {
          index
        } = req.body;
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const mappings = await callAsCurrentUser('indices.getMapping', {
          index
        });
        return res.ok({
          body: {
            ok: true,
            resp: mappings
          }
        });
      } catch (err) {
        console.error('Alerting - ElasticsearchService - getMappings:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getPlugins", async (context, req, res) => {
      try {
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const plugins = await callAsCurrentUser('cat.plugins', {
          format: 'json',
          h: 'component'
        });
        return res.ok({
          body: {
            ok: true,
            resp: plugins
          }
        });
      } catch (err) {
        console.error('Alerting - ElasticsearchService - getPlugins:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getSettings", async (context, req, res) => {
      try {
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const settings = await callAsCurrentUser('cluster.getSettings', {
          include_defaults: 'true'
        });
        return res.ok({
          body: {
            ok: true,
            resp: settings
          }
        });
      } catch (err) {
        console.error('Alerting - ElasticsearchService - getSettings:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  } // TODO: This will be deprecated as we do not want to support accessing alerting indices directly
  //  and that is what this is used for


}

exports.default = ElasticsearchService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkVsYXN0aWNzZWFyY2hTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIkVsYXN0aWNzZWFyY2hTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJxdWVyeSIsImluZGV4Iiwic2l6ZSIsImJvZHkiLCJwYXJhbXMiLCJjYWxsQXNDdXJyZW50VXNlciIsImFzU2NvcGVkIiwicmVzdWx0cyIsIm9rIiwicmVzcCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIm1lc3NhZ2UiLCJpbmRpY2VzIiwiZm9ybWF0IiwiaCIsInN0YXR1c0NvZGUiLCJhbGlhcyIsImFsaWFzZXMiLCJtYXBwaW5ncyIsInBsdWdpbnMiLCJzZXR0aW5ncyIsImluY2x1ZGVfZGVmYXVsdHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7OztBQWVlLE1BQU1BLG9CQUFOLENBQTJCO0FBQ3hDQyxFQUFBQSxXQUFXLENBQUNDLFFBQUQsRUFBVztBQUFBLG9DQU1iLE9BQU9DLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUNwQyxVQUFJO0FBQ0YsY0FBTTtBQUFFQyxVQUFBQSxLQUFGO0FBQVNDLFVBQUFBLEtBQVQ7QUFBZ0JDLFVBQUFBO0FBQWhCLFlBQXlCSixHQUFHLENBQUNLLElBQW5DO0FBQ0EsY0FBTUMsTUFBTSxHQUFHO0FBQUVILFVBQUFBLEtBQUY7QUFBU0MsVUFBQUEsSUFBVDtBQUFlQyxVQUFBQSxJQUFJLEVBQUVIO0FBQXJCLFNBQWY7QUFDQSxjQUFNO0FBQUVLLFVBQUFBO0FBQUYsWUFBd0IsS0FBS1QsUUFBTCxDQUFjVSxRQUFkLENBQXVCUixHQUF2QixDQUE5QjtBQUNBLGNBQU1TLE9BQU8sR0FBRyxNQUFNRixpQkFBaUIsQ0FBQyxRQUFELEVBQVdELE1BQVgsQ0FBdkM7QUFDQSxlQUFPTCxHQUFHLENBQUNTLEVBQUosQ0FBTztBQUNaTCxVQUFBQSxJQUFJLEVBQUU7QUFDSkssWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFRjtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FYRCxDQVdFLE9BQU9HLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYywwQ0FBZCxFQUEwREYsR0FBMUQ7QUFDQSxlQUFPWCxHQUFHLENBQUNTLEVBQUosQ0FBTztBQUNaTCxVQUFBQSxJQUFJLEVBQUU7QUFDSkssWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBM0JxQjs7QUFBQSx3Q0E2QlQsT0FBT2hCLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN4QyxVQUFJO0FBQ0YsY0FBTTtBQUFFRSxVQUFBQTtBQUFGLFlBQVlILEdBQUcsQ0FBQ0ssSUFBdEI7QUFDQSxjQUFNO0FBQUVFLFVBQUFBO0FBQUYsWUFBd0IsS0FBS1QsUUFBTCxDQUFjVSxRQUFkLENBQXVCUixHQUF2QixDQUE5QjtBQUNBLGNBQU1nQixPQUFPLEdBQUcsTUFBTVQsaUJBQWlCLENBQUMsYUFBRCxFQUFnQjtBQUNyREosVUFBQUEsS0FEcUQ7QUFFckRjLFVBQUFBLE1BQU0sRUFBRSxNQUY2QztBQUdyREMsVUFBQUEsQ0FBQyxFQUFFO0FBSGtELFNBQWhCLENBQXZDO0FBS0EsZUFBT2pCLEdBQUcsQ0FBQ1MsRUFBSixDQUFPO0FBQ1pMLFVBQUFBLElBQUksRUFBRTtBQUNKSyxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVLO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWRELENBY0UsT0FBT0osR0FBUCxFQUFZO0FBQ1o7QUFDQSxZQUFJQSxHQUFHLENBQUNPLFVBQUosS0FBbUIsR0FBdkIsRUFBNEI7QUFDMUIsaUJBQU9sQixHQUFHLENBQUNTLEVBQUosQ0FBTztBQUNaTCxZQUFBQSxJQUFJLEVBQUU7QUFDSkssY0FBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsY0FBQUEsSUFBSSxFQUFFO0FBRkY7QUFETSxXQUFQLENBQVA7QUFNRCxTQVBELE1BT087QUFDTEUsVUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsK0NBQWQsRUFBK0RGLEdBQS9EO0FBQ0EsaUJBQU9YLEdBQUcsQ0FBQ1MsRUFBSixDQUFPO0FBQ1pMLFlBQUFBLElBQUksRUFBRTtBQUNKSyxjQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxjQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFdBQVAsQ0FBUDtBQU1EO0FBQ0Y7QUFDRixLQS9EcUI7O0FBQUEsd0NBaUVULE9BQU9oQixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDeEMsVUFBSTtBQUNGLGNBQU07QUFBRW1CLFVBQUFBO0FBQUYsWUFBWXBCLEdBQUcsQ0FBQ0ssSUFBdEI7QUFDQSxjQUFNO0FBQUVFLFVBQUFBO0FBQUYsWUFBd0IsS0FBS1QsUUFBTCxDQUFjVSxRQUFkLENBQXVCUixHQUF2QixDQUE5QjtBQUNBLGNBQU1xQixPQUFPLEdBQUcsTUFBTWQsaUJBQWlCLENBQUMsYUFBRCxFQUFnQjtBQUNyRGEsVUFBQUEsS0FEcUQ7QUFFckRILFVBQUFBLE1BQU0sRUFBRSxNQUY2QztBQUdyREMsVUFBQUEsQ0FBQyxFQUFFO0FBSGtELFNBQWhCLENBQXZDO0FBS0EsZUFBT2pCLEdBQUcsQ0FBQ1MsRUFBSixDQUFPO0FBQ1pMLFVBQUFBLElBQUksRUFBRTtBQUNKSyxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVVO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWRELENBY0UsT0FBT1QsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLCtDQUFkLEVBQStERixHQUEvRDtBQUNBLGVBQU9YLEdBQUcsQ0FBQ1MsRUFBSixDQUFPO0FBQ1pMLFVBQUFBLElBQUksRUFBRTtBQUNKSyxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0F6RnFCOztBQUFBLHlDQTJGUixPQUFPaEIsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDLFVBQUk7QUFDRixjQUFNO0FBQUVFLFVBQUFBO0FBQUYsWUFBWUgsR0FBRyxDQUFDSyxJQUF0QjtBQUNBLGNBQU07QUFBRUUsVUFBQUE7QUFBRixZQUF3QixLQUFLVCxRQUFMLENBQWNVLFFBQWQsQ0FBdUJSLEdBQXZCLENBQTlCO0FBQ0EsY0FBTXNCLFFBQVEsR0FBRyxNQUFNZixpQkFBaUIsQ0FBQyxvQkFBRCxFQUF1QjtBQUFFSixVQUFBQTtBQUFGLFNBQXZCLENBQXhDO0FBQ0EsZUFBT0YsR0FBRyxDQUFDUyxFQUFKLENBQU87QUFDWkwsVUFBQUEsSUFBSSxFQUFFO0FBQ0pLLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRVc7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BVkQsQ0FVRSxPQUFPVixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1gsR0FBRyxDQUFDUyxFQUFKLENBQU87QUFDWkwsVUFBQUEsSUFBSSxFQUFFO0FBQ0pLLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQS9HcUI7O0FBQUEsd0NBaUhULE9BQU9oQixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDeEMsVUFBSTtBQUNGLGNBQU07QUFBRU0sVUFBQUE7QUFBRixZQUF3QixLQUFLVCxRQUFMLENBQWNVLFFBQWQsQ0FBdUJSLEdBQXZCLENBQTlCO0FBQ0EsY0FBTXVCLE9BQU8sR0FBRyxNQUFNaEIsaUJBQWlCLENBQUMsYUFBRCxFQUFnQjtBQUNyRFUsVUFBQUEsTUFBTSxFQUFFLE1BRDZDO0FBRXJEQyxVQUFBQSxDQUFDLEVBQUU7QUFGa0QsU0FBaEIsQ0FBdkM7QUFJQSxlQUFPakIsR0FBRyxDQUFDUyxFQUFKLENBQU87QUFDWkwsVUFBQUEsSUFBSSxFQUFFO0FBQ0pLLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRVk7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BWkQsQ0FZRSxPQUFPWCxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsK0NBQWQsRUFBK0RGLEdBQS9EO0FBQ0EsZUFBT1gsR0FBRyxDQUFDUyxFQUFKLENBQU87QUFDWkwsVUFBQUEsSUFBSSxFQUFFO0FBQ0pLLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXZJcUI7O0FBQUEseUNBeUlSLE9BQU9oQixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDekMsVUFBSTtBQUNGLGNBQU07QUFBRU0sVUFBQUE7QUFBRixZQUF3QixLQUFLVCxRQUFMLENBQWNVLFFBQWQsQ0FBdUJSLEdBQXZCLENBQTlCO0FBQ0EsY0FBTXdCLFFBQVEsR0FBRyxNQUFNakIsaUJBQWlCLENBQUMscUJBQUQsRUFBd0I7QUFDOURrQixVQUFBQSxnQkFBZ0IsRUFBRTtBQUQ0QyxTQUF4QixDQUF4QztBQUdBLGVBQU94QixHQUFHLENBQUNTLEVBQUosQ0FBTztBQUNaTCxVQUFBQSxJQUFJLEVBQUU7QUFDSkssWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFYTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FYRCxDQVdFLE9BQU9aLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyxnREFBZCxFQUFnRUYsR0FBaEU7QUFDQSxlQUFPWCxHQUFHLENBQUNTLEVBQUosQ0FBTztBQUNaTCxVQUFBQSxJQUFJLEVBQUU7QUFDSkssWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBOUpxQjs7QUFDcEIsU0FBS2pCLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0QsR0FIdUMsQ0FLeEM7QUFDQTs7O0FBTndDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IDIwMTkgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEVsYXN0aWNzZWFyY2hTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IoZXNEcml2ZXIpIHtcbiAgICB0aGlzLmVzRHJpdmVyID0gZXNEcml2ZXI7XG4gIH1cblxuICAvLyBUT0RPOiBUaGlzIHdpbGwgYmUgZGVwcmVjYXRlZCBhcyB3ZSBkbyBub3Qgd2FudCB0byBzdXBwb3J0IGFjY2Vzc2luZyBhbGVydGluZyBpbmRpY2VzIGRpcmVjdGx5XG4gIC8vICBhbmQgdGhhdCBpcyB3aGF0IHRoaXMgaXMgdXNlZCBmb3JcbiAgc2VhcmNoID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgcXVlcnksIGluZGV4LCBzaXplIH0gPSByZXEuYm9keTtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgaW5kZXgsIHNpemUsIGJvZHk6IHF1ZXJ5IH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ3NlYXJjaCcsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IHJlc3VsdHMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gRWxhc3RpY3NlYXJjaFNlcnZpY2UgLSBzZWFyY2gnLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0SW5kaWNlcyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGluZGV4IH0gPSByZXEuYm9keTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGluZGljZXMgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignY2F0LmluZGljZXMnLCB7XG4gICAgICAgIGluZGV4LFxuICAgICAgICBmb3JtYXQ6ICdqc29uJyxcbiAgICAgICAgaDogJ2hlYWx0aCxpbmRleCxzdGF0dXMnLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGluZGljZXMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEVsYXN0aWNzZWFyY2ggdGhyb3dzIGFuIGluZGV4X25vdF9mb3VuZF9leGNlcHRpb24gd2hpY2ggd2UnbGwgdHJlYXQgYXMgYSBzdWNjZXNzXG4gICAgICBpZiAoZXJyLnN0YXR1c0NvZGUgPT09IDQwNCkge1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICAgIHJlc3A6IFtdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBFbGFzdGljc2VhcmNoU2VydmljZSAtIGdldEluZGljZXM6JywgZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGdldEFsaWFzZXMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBhbGlhcyB9ID0gcmVxLmJvZHk7XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBhbGlhc2VzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2NhdC5hbGlhc2VzJywge1xuICAgICAgICBhbGlhcyxcbiAgICAgICAgZm9ybWF0OiAnanNvbicsXG4gICAgICAgIGg6ICdhbGlhcyxpbmRleCcsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogYWxpYXNlcyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBFbGFzdGljc2VhcmNoU2VydmljZSAtIGdldEFsaWFzZXM6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldE1hcHBpbmdzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaW5kZXggfSA9IHJlcS5ib2R5O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgbWFwcGluZ3MgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignaW5kaWNlcy5nZXRNYXBwaW5nJywgeyBpbmRleCB9KTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogbWFwcGluZ3MsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gRWxhc3RpY3NlYXJjaFNlcnZpY2UgLSBnZXRNYXBwaW5nczonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0UGx1Z2lucyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBwbHVnaW5zID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2NhdC5wbHVnaW5zJywge1xuICAgICAgICBmb3JtYXQ6ICdqc29uJyxcbiAgICAgICAgaDogJ2NvbXBvbmVudCcsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogcGx1Z2lucyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBFbGFzdGljc2VhcmNoU2VydmljZSAtIGdldFBsdWdpbnM6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldFNldHRpbmdzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2NsdXN0ZXIuZ2V0U2V0dGluZ3MnLCB7XG4gICAgICAgIGluY2x1ZGVfZGVmYXVsdHM6ICd0cnVlJyxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBzZXR0aW5ncyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBFbGFzdGljc2VhcmNoU2VydmljZSAtIGdldFNldHRpbmdzOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn1cbiJdfQ==